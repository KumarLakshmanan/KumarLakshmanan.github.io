<?php

header('Content-Type: text/html; charset=utf-8');
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

session_start();
include 'common/inc.common.php';

$sql = "select * from discount where active=1";
$disarr = $Cobj->union($sql);

$r = $_SESSION['r'];
$tableno = $_SESSION['tableno'];
$selectroom = $_SESSION['roomno'];
$selectguest = $_SESSION['guestname'];

//To get IP and URL when an error accures
$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$useragent = $_SERVER['HTTP_USER_AGENT'];
$myip = $_SERVER['REMOTE_ADDR'];

// if guest information such as r value or table,roomno,guestname inside r value are available or double entred
if (empty($tableno) || empty($selectroom) || empty($selectguest) || count($selectguest) > 1) {
  $file = fopen("log.txt", "a");
  $date = date('Y-m-d H:i:s');
  fwrite($file, "\n $date  Error : テーブル番号：部屋番号：お客様の名前 (Not Found) \n r = $r \n IP : ($myip) \n URL : $actual_link \n スマホ情報: $useragent" . PHP_EOL . "--------------------------------------------------");
  fclose($file);
  header('HTTP/1.1 404 Not Found');
  include '404.php';
  exit();
}

?>


<!DOCTYPE html>
<html lang="ja-jp">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=0.9, maximum-scale=0.9, user-scalable=0">
  <meta name="theme-color" content="#c9ad86">
  <meta name="msapplication-navbutton-color" content="#c9ad86">
  <meta name="apple-mobile-web-app-status-bar-style" content="#c9ad86">

  <meta http-equiv="pragma" content="no-cache">
  <meta http-equiv="cache-control" content="no-cache">
  <meta http-equiv="expires" content="0">

  <link rel="icon" href="images/top-icon.png">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/w3.css">

  <!-- W3 css -->
  <link rel="stylesheet" href="css/w3.css">

  <!-- jQuery library -->
  <script src="js/jquery-2-1-1.js"></script>

  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="css/bootstrap-4.5.3-dist/css/bootstrap.min.css">

  <!-- jQuery library -->
  <script src="js/jquery-3-5-1.js"></script>

  <!-- Popper JS -->
  <script src="js/popper-1-16-0.js"></script>

  <!-- Latest compiled JavaScript -->
  <script src="css/bootstrap-4.5.3-dist/js/bootstrap.min.js"></script>


  <title>Menu</title>
  <style>
    table {
      width: 100%;
      margin-left: auto;
      margin-right: auto;
      max-width: 350px;
      border-collapse: collapse;
      text-align: center;
      border: 1px solid black;
      font-size: 12px;
    }

    .roomname {
      margin-left: 5%;
      margin-top: 20px;
      font-family: 'Arial Narrow Bold', sans-serif;
      font-weight: 900;

    }

    .blackhead {

      background-color: black;
      color: aliceblue;
      height: 40px;
      font-size: 15px;
    }

    .blackhead-content {
      font-size: 15px;
      background-color: white;
    }
  </style>

</head>

<body style="background-color: #e3d3bf;" onload="history.replaceState('', '', 'bestof.php?r=<?php echo $_SESSION['r']; ?>');">

  <div class="containerPlus2">

    <!----------------------------------Top Menu------------------------------------->
    <div class="fixme">
      <!--cart's floating quantity button-->
      <div style="position: absolute; right:15px;top:53px">
        <button class="button2 button1-color" onclick="location.href='checkout_cart.php';"> <span class="total-count"></span> </button> <br>
        <input type="text" name="discper" id="discper" hidden readonly value="<?php echo $disarr[0]['disc_per']; ?>">
        <input type="text" name="finaltot" id="finaltot" readonly="" value="" hidden>
      </div>

      <img style="width: 384px; height:120px;" src="images/cutout/top-menu.jpeg" usemap="#image-map">
      <map name="image-map" style="cursor: pointer;">

        <!--guest name and room number-->
        <div class="top-left-room">
          <p><?php echo $_SESSION['roomno']; ?></p>
        </div>
        <div class="top-left-guest">
          <p><?php echo $_SESSION['guestname']; ?></p>
        </div>

        <!--Change User-->
        <area target="" alt="" title="" href="bestof.php?r=<?php echo $_SESSION['r']; ?>" coords="1,60,95,115" shape="rect">

        <!--Home-->
        <area target="" alt="" title="" href="index.php?r=<?php echo $_SESSION['r']; ?>" coords="98,60,190,115" shape="rect">

        <!--History-->
        <area target="" alt="" title="" href="order01.php?r=<?php echo $_SESSION['r']; ?>" coords="193,60,286,115" shape="rect">

        <!--Cart-->
        <area target="" alt="" title="" href="checkout_cart.php" coords="289,60,382,115" shape="rect">


      </map>
    </div>


    <!----------------------------------- Mid-Top Menu ------------------------------->
    <div class="midmenu">
      <img style="width: 384px; height:auto" src="images/cutout/mid-menu.jpeg" usemap="#image-map2">
      <map name="image-map2" style="cursor: pointer;">


        <!-- オリジナルボトル -->
        <area target="" alt="" title="" href="menu01.php?menuid=menu01" class="tablinks" onclick="openCity(event, 'menu01')" coords="2,2,126,110" shape="rect">

        　　　　　　　　　　　　　　
        <!-- 日本酒　。焼酎 -->
        <area target="" alt="" title="" href="menu01.php?menuid=menu02" class="tablinks" onclick="openCity(event, 'menu02')" coords="130,2,255,110" shape="rect">

        <!--ビール　。ウイスキー　-->
        <area target="" alt="" title="" href="menu01.php?menuid=menu03" class="tablinks" onclick="openCity(event, 'menu03')" coords="258,2,382,110" shape="rect">



        　　　　　　　　　　　　　　
        <!-- サワー　。　果実酒　-->
        <area target="" alt="" title="" href="menu01.php?menuid=menu04" class="tablinks" onclick="openCity(event, 'menu04')" coords="2,112,126,284" shape="rect">

        <!--ワイン-->
        <area target="" alt="" title="" href="menu01.php?menuid=menu05" class="tablinks" onclick="openCity(event, 'menu05')" coords="130,112,255,284" shape="rect">

        <!--ソフトドリンク-->
        <area target="" alt="" title="" href="menu01.php?menuid=menu06" class="tablinks" onclick="openCity(event, 'menu06')" coords="258,112,382,284" shape="rect">
      </map>
    </div>


  </div>

  <!-------------------------------------------------->

  <div id="menu01" class="tabcontent">


    <?php
    $total = 0;
    $gnold = '';
    $roomnoOld = '';

    $uniqueid = $_SESSION['uniqueid'];
    $sql = "select * from confirmedorders where or_userid='$uniqueid' and (user_cd='OK') order by guestname,updated";
    $dataarrord = $Cobj->union($sql);

    if ($dataarrord != null) {

      for ($i = 0; $i < sizeof($dataarrord); $i++) {
        $count = count($dataarrord);
        $gn = $dataarrord[$i]['guestname'];
        $roomno = $dataarrord[$i]['roomno'];
        $qty = $dataarrord[$i]['productquantity'];
        $pri = $dataarrord[$i]['productprice'];
        $tot = (int)$pri * (int)$qty;

        if ($gnold != $gn || $roomnoOld != $roomno) {
          echo "<table id='customers'>";

          //".$dataarrord[$i]['tableno']." 
          echo "<div class='roomname' style='font-weight=900;'> " . $dataarrord[$i]['roomno'] . "  " . $dataarrord[$i]['guestname'] . "　様</div><br>";
          echo " <tr class='blackhead'> <th style='width:75%'>商品名</th>	  <th>数量</th> <th>金額</th>  </tr>";
          echo " <tr class='blackhead-content'>		  <td>" . $dataarrord[$i]['productname'] . "</td>	  <td>" . $dataarrord[$i]['productquantity'] . "</td> <td>" . number_format($pri) . "</td>  </tr>";
          $total = $total + $tot;
        } else {
          echo " <tr class='blackhead-content'>		  <td>" . $dataarrord[$i]['productname'] . "</td>	  <td>" . $dataarrord[$i]['productquantity'] . "</td> <td>" . number_format($pri) . "</td>  </tr>";
          $total = $total + $tot;
        }


        $j = $i + 1;
        if (isset($dataarrord[$j]['guestname']) && ($dataarrord[$j]['guestname'] != $gn || $dataarrord[$j]['roomno'] != $roomno)) {
          echo " <tr style='background-color:white;font-size:18px;'>		  <td style=';font-weight:900;' >合計金額</td>	  <td colspan='2'>" . number_format($total) . '円' . "</td>  </tr>";
          echo " </table>";
          $total = 0;
        }
        if (($j - 1) == ($count - 1)) {
          echo " <tr style='background-color:white;font-size:18px;'>		  <td style=';font-weight:900;'>合計金額</td>	   <td colspan='2'>" . number_format($total) . '円' . "</td> </tr>";
          echo " </table>";
          $total = 0;
          break;
        }

        $gnold = $dataarrord[$i]['guestname'];
        $roomnoOld = $dataarrord[$i]['roomno'];
      }
    } else {
      echo "<div class='ordernoufound'>ご注文が見つかりませんでした。</div>";
    }

    ?>

  </div>

  <!---------------------------------------->
  <div class="footer">
    <hr class="solid">
    <span style="color: #595143; font-size:8px"> ® <script type="text/javascript">
        document.write(new Date().getFullYear());
      </script> Yunokawa Prince Hotel Nagisatei • All Rights Reserved</span>
  </div>
  <!--------------------------------------->
  <script src="js/main.js"></script>

  <!-- top menu fixed on scroll -->
  <script>
    var firstElHeight = $('.fixme').height();
    var midmenuEl = $('.midmenu');
    midmenuEl.css('marginTop', firstElHeight + 'px');
  </script>


</body>

</html>