<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");


include '../common/inc.common.php';

if (isset($_SESSION['staffbango']) && isset($_SESSION['roombango'])) {
    $staffcd = $_SESSION['staffbango'];
    $roomno = $_SESSION['roombango'];


  $todate = date('Y-m-d');
  $sql = "select * from confirmedorders where or_userid like '%$roomno%' and updated like '$todate%' and user_cd='OK' order by roomno,updated";
  $result = mysqli_query($conn, $sql)
    or die('error quering database');

  $count = mysqli_num_rows($result);

?>


  <!DOCTYPE html>
  <html lang="ja-jp">

  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="theme-color" content="#c9ad86">
    <meta name="msapplication-navbutton-color" content="#c9ad86">
    <meta name="apple-mobile-web-app-status-bar-style" content="#c9ad86">

    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">

    <!-- <link rel="icon" href="images/top-icon.png"> -->
    <link rel="stylesheet" href="../css/main.css">
    
    
    <script src="../assets/js/jquery-2-1-1.js"></script>


    <title>セルフオーダー注文取り消し</title>
    <style>
      table {
        width: 100%;
        margin-left: auto;
        margin-right: auto;
        max-width: 350px;
        border-collapse: collapse;
        text-align: center;
        border: 1px solid black;
        font-size: 18px;
      }

      .roomname {
        margin-left: 5%;
        margin-top: 20px;
        font-family: 'Arial Narrow Bold', sans-serif;
      }

      .blackhead {
        background-color: black;
        color: aliceblue;
      }

      input[type=checkbox] {
        /* Double-sized Checkboxes */
        -ms-transform: scale(1.5);
        /* IE */
        -moz-transform: scale(1.5);
        /* FF */
        -webkit-transform: scale(1.5);
        /* Safari and Chrome */
        -o-transform: scale(1.5);
        /* Opera */
        transform: scale(1.5);
        padding: 10px;
      }

      .footer { 
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
      }
    </style>


    <script type='text/javascript'>
      $(document).ready(function() {
        //option A
        $("#cartform").submit(function(e) {
          var ver = "";
          e.preventDefault();
          $('#loading').show();
          $.ajax({
            url: "deleteoption.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
              data = data.trim();
              console.log(data);
              if (data == "failed") {
                window.location.href = "cancel.php";
              } else {
                window.location.href = "cancellist.php";
              }
            },
            error: function(error, exception) {
              window.location.href = '../../404.php';
            }
          });
        });
      });
    </script>

  </head>

  <!-- if you add request wont be able to be sent  
   style="background-color: #e3d3bf;" onload="history.replaceState('', '', 'http://rest.yunokawapn.co.jp/res_n/res_self.pl');"-->
  <body  >

     

    <div style="float:left;font-size:20px"> 担当者 : <?php echo $staffcd ?> </div>
    <div style="text-align: right;font-size:20px; "> 部屋番号 : <?php echo $roomno; ?> </div> <br>

    <!-------------------------------------------------->
    <h3 style="text-align: center;">注文取り消し</h3>
    <form name="form1" method="POST" id="cartform" action="deleteoption.php">
      <input type="text" name="staffbango" value="<?php echo $staffcd; ?>" hidden>
      <?php

      $gusetNameOld = '';
      $roomnoOld = '';
      // if ($gnold != $gn) {
      ?>

      <?php
      $i = 0;
      while ($row = mysqli_fetch_array($result)) {
        $j = $i + 1;
        $qty=$row['productquantity'];
        $pri=$row['productprice'];
        $tot=$pri*$qty;
        $gusetName = $row['guestname'];
        $roomno = $row['roomno'];
        if ($gusetNameOld != $gusetName || $roomnoOld != $roomno) {
          ?>
          <table width="375" border="0" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC">
            <?php
            echo "<div class='roomname' style='font-weight=900;'> " . $row['roomno'] . "  " . $row['guestname'] . "　様</div><br>";
            ?>
            <tr class='blackhead'>
              <th style="width: 9%;"> &nbsp; </th>
              <th>商品名</th>
              <th style='width:15%'>数量</th>
              <th style='width:15%'>金額</th>
            </tr>
          <?php
        }
          ?>
          <tr style="font-size: 15px;line-height:30px">
            <td align="center" bgcolor="#e3d3bf"><input name="checkbox[]" type="checkbox" value="<?php echo $row['or_ref_id'] . "____" . $i; ?>"></td>
            <td bgcolor="#e3d3bf"><?php echo $row['productname']; ?></td>
            <td bgcolor="#e3d3bf"><?php echo $row['productquantity']; ?></td>
            <td bgcolor="#e3d3bf"><?php echo $pri; ?></td>
            <input type="text" name="cd1[]" value="<?php echo $row['cd1']; ?>" hidden>
            <input type="text" name="cd2[]" value="<?php echo $row['cd2']; ?>" hidden>
            <input type="text" name="productname[]" value="<?php echo $row['productname']; ?>" hidden>
            <input type="text" name="guestname" value="<?php echo $row['guestname']; ?>" hidden>
            <input type="text" name="roomno" value="<?php echo $row['roomno']; ?>" hidden>
            <input type="text" name="productquantity[]" value="<?php echo $row['productquantity']; ?>" hidden>
            <input type="text" name="productprice[]" value="<?php echo $row['productprice']; ?>" hidden>
            <input type="text" name="tableno" value="<?php echo $row['tableno']; ?>" hidden>
          </tr>
        <?php
        if (($j - 1) == ($count - 1)) {
          echo " </table>";
          break;
        }
        $i++;

        $gusetNameOld = $gusetName;
        $roomnoOld = $roomno;
      }
        ?>
          </table>

          <div style="float: left;width:100%;margin-top:15px;">
            <input type="hidden" name="validate" value="YES">
            <input type="hidden" name="delete" value="取り消し">
            <input name="deleteBTN" type="submit" value="取り消し" style="width: 150px;height:65px; background-color:red;font-size:20px;color:white">
            <button style="width: 150px;background-color:green;height:65px;border-radius:8px;font-size:20px;color:white;border:none" onclick="location.href='cancel.php?uid=<?php echo $staffcd ?>'" type="button">戻る</button>
          </div>
    </form>
    



  </body>

  </html>
<?php

} else {
  header('Location: cancel.php');
}
