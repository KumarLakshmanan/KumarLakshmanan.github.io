document.getElementsByTagName("html")[0].style.fontSize = "12px";
var myModalContent = `
  <button type="button" id="myModalOpen" class="btn btn-primary rounded-0 p-3" data-toggle="modal" data-target="#exampleModal" style="position: fixed;bottom: 0;right: 0;z-index: 9999999;width:120px;height:40px;">
      Scrape Data
  </button>
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true" style="background: rgba(0,0,0,0.7);z-index:9999999">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel" style="margin:0">Proptension</h5>
                <button type="button" class="close btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <label for="phone_count">Pull Count</label>
                <div class="input-group mb-3">
                  <input type="text" class="form-control" id="exampleModalpull_count" placeholder="Property Pulling Count">
                </div>
                <br/>
                <label for="phone_count">Page Number</label>
                <div class="input-group mb-3">
                  <input type="text" class="form-control" id="exampleModalpage" placeholder="Page Of Pulling">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" id="ScrapData" class="btn btn-primary">Scrap Data</button>
            </div>
        </div>
    </div>
  </div>`;
var myModal = document.createElement("div");
myModal.innerHTML = myModalContent;
myModal.setAttribute("id", "myModal");
var modal = myModal.querySelector(".modal");
var pull_count = myModal.querySelector("#exampleModalpull_count");
var pagePulling = myModal.querySelector("#exampleModalpage");
var scrapSubmit = myModal.querySelector("#ScrapData");

myModal.querySelector(".btn-close").addEventListener("click", function () {
  modal.style.display = "none";
  modal.classList.remove("show");
});
myModal.querySelector("#myModalOpen").addEventListener("click", function () {
  modal.style.display = "block";
  modal.classList.add("show");
});
scrapSubmit.addEventListener("click", async function () {
  scrapSubmit.style.pointerEvents = "none";
  scrapSubmit.style.opacity = "0.5";
  scrapSubmit.innerHTML = "Fetching...";
  totalPages = 999999999999999;
  var myData = [];
  try {
    for (var i = parseInt(pagePulling.value); i <= totalPages; i++) {
      let a = "";
      "" !== document.getElementById("hidSelectedLocation").value &&
        (a = document.getElementById("hidSelectedLocation").value);
      let s = {
          fromPrice: 0,
          toPrice: 0,
          fromArea: 0,
          toArea: 0,
          areaUnit: "sq feet",
        },
        r = document.getElementById("hidAreaFilter").value,
        o = document.getElementById("hidPriceFilter").value;
      if ("" !== o) {
        let e = o.split(":");
        (s.fromPrice = e[0]), (s.toPrice = e[1]);
      }
      if ("" !== r) {
        let e = r.split(":");
        (s.fromArea = e[0]), (s.toArea = e[1]), (s.areaUnit = e[2]);
      }
      if (myData.length >= pull_count.value) break;
      var response = await fetch("/core5/api/adlistings/get-ads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          CityId: document.getElementById("hidCityId").value,
          SubCategoryId: document.getElementById("hidCategoryId").value,
          NeedFilterValues: document.getElementById("hidattributefilter").value,
          LocalityFilter: a,
          OrderBy: document.getElementById("hidsortbyfilter").value,
          NearbyLocalityFilter: document.getElementById(
            "hidNearbyLocalityFilter"
          ).value,
          PageNr: i,
          RowsToFetch: 10,
          NeedId: 0,
          Areaid: document.getElementById("hidAreaId").value,
          adClassificationOption: parseInt(
            document.getElementById("hidAdClassification").value
          ),
          FromPrice: s.fromPrice,
          ToPrice: s.toPrice,
          FromArea: s.fromArea,
          ToArea: s.toArea,
          AreaUnit: s.areaUnit,
          RouteId: document.getElementById("hidRouteId").value,
          IsMobile: false,
          StateName: document.getElementById("hidStateName").value,
        }),
      });
      var data = await response.text();
      if (data.trim() == "") {
        break;
      } else {
        var newDiv = document.createElement("div");
        newDiv.setAttribute("id", "hiddenIdDiv");
        newDiv.innerHTML = data;
        var hiddenId = newDiv.querySelectorAll(".list-card");
        newDiv.remove();
        for (var j = 0; j < hiddenId.length; j++) {
          myData.push(await getPropertyDetails(hiddenId[j]));
          scrapSubmit.innerHTML = "Fetching " + myData.length + " Properties";
          if (myData.length % 20 == 0) {
            alert("Warning:: Change Your IP Address to Avoid Blocking");
          }
          if (pull_count.value == myData.length) {
            downloadExcel(myData);
            return;
          }
        }
      }
    }
    downloadExcel(myData);
    return;
  } catch (error) {
    console.log(error);
    downloadExcel(myData);
  }
});
function downloadExcel($json) {
  fetch("https://tab2chat.000webhostapp.com/api/jsonToCsv.php?from=sulekha", {
    method: "POST",
    body: JSON.stringify($json),
  }).then(function (response) {
    var url = "https://tab2chat.000webhostapp.com/api/sulekha.csv";
    var a = document.createElement("a");
    a.href = url;
    a.download =
      new Date().getFullYear() +
      "-" +
      (new Date().getMonth() + 1) +
      "-" +
      new Date().getDate() +
      ".csv";
    a.click();
    scrapSubmit.innerHTML = "Done.";
    scrapSubmit.style.pointerEvents = "all";
    scrapSubmit.style.opacity = "1";
  });
}
async function getPropertyDetails(_data) {
  var div = document.createElement("div");
  div.setAttribute("id", "MyhiddenIdDiv");
  document.body.appendChild(div);
  div.innerHTML = _data.innerHTML;
  var propertyDetails = {};
  div = document.getElementById("MyhiddenIdDiv") || "N/A";
  propertyDetails.Id =
    div.querySelector(".btn-group.block button") == null
      ? "N/A"
      : div
          .querySelector(".btn-group.block button")
          .getAttribute("data-contentid");
  // propertyDetails.PostedOn = removeHtmlTags(
  //   div.querySelector(".view-gallery") == null
  //     ? "N/A"
  //     : getTime(div.querySelector(".view-gallery").getAttribute("data-original").split("thumbnail/")[1].replace(".jpeg", ""))
  // );
  propertyDetails.Title =
    div.querySelector(".business .name a") == null
      ? "N/A"
      : div.querySelector(".business .name a").innerText.trim();
  propertyDetails.Url =
    div.querySelector(".business .name a") == null
      ? "N/A"
      : div.querySelector(".business .name a").getAttribute("href");
  propertyDetails.Brand = removeHtmlTags(
    div.querySelector(".business .brand-name") == null
      ? "N/A"
      : div
          .querySelector(".business .brand-name")
          .innerText.trim()
          .replace("by ", "")
  );
  propertyDetails.Locality = removeHtmlTags(
    div.querySelector(".business .data .locality") == null
      ? "N/A"
      : div.querySelector(".business .data .locality").innerText.trim()
  );
  propertyDetails.Description =
    div.querySelector(".desc .readless") == null
      ? "N/A"
      : div.querySelector(".desc .readless").innerText.trim();
  propertyDetails.Tags = removeHtmlTags(
    div.querySelector(".tags") == null
      ? "N/A"
      : div.querySelector(".tags").innerText.trim()
  );
  propertyDetails.dataPoints = removeHtmlTags(
    div.querySelector(".data-points") == null
      ? "N/A"
      : div.querySelector(".data-points").innerText.trim()
  );
  propertyDetails.keyPoint = removeHtmlTags(
    div.querySelector(".key-points") == null
      ? "N/A"
      : div.querySelector(".key-points").innerText.trim().replace("Config", "")
  );
  propertyDetails.Pricing = removeHtmlTags(
    div.querySelector(".ratings-group") == null
      ? "N/A"
      : div.querySelector(".ratings-group").innerText.trim()
  );
  var detPhone = await getBuilderContactNumber(
    div.querySelector(".btn-group.block button").getAttribute("data-id")
  );
  if (detPhone.length > 0) {
    propertyDetails.Name = "";
    propertyDetails.Email = "";
    propertyDetails.Number = "";
  } else {
    propertyDetails.Name = detPhone.name;
    propertyDetails.Email = detPhone.email;
    propertyDetails.Number = detPhone.phone;
  }
  div.remove();
  return propertyDetails;
}
function convertEpochToDate(epoch) {
  var date = new Date(epoch);
  return (
    date.getHours() +
    ":" +
    date.getMinutes() +
    " " +
    date.getDate() +
    "/" +
    date.getMonth() +
    "/" +
    date.getFullYear()
  );
}
async function getBuilderContactNumber(listingId) {
  listingId = listingId.split("|");
  var response1 = await fetch(
    "/core5/api/common/get-contact-details?adid=" +
      listingId[0] +
      "&BusinessId=" +
      listingId[1],
    {
      method: "GET",
      credentials: "same-origin",
    }
  );
  var response2Json = await response1.json();
  console.log(response2Json);
  return {
    name: response2Json[0].name,
    phone: response2Json[0].countryCode + " " + response2Json[0].mobileNo,
    email: response2Json[0].emailId,
  };
}
document.body.appendChild(myModal);

removeHtmlTags = function (str) {
  // Remove HTML-Tags and -Entities and return cleaned one line string without linebreaks. and two spaces
  return str
    .replace(/<\/?[^>]+(>|$)/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/\s\s+/g, " ")
    .trim();
};

getTime = function (str) {
  str = str.split("_");
  return str[2] + "-" + str[1] + "-" + str[0];
};
