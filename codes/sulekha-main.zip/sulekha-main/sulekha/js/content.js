var s = document.createElement("script");
s.src = chrome.runtime.getURL("/sulekha/js/search.js");
document.head.appendChild(s);

var style = document.createElement("link");
style.rel = "stylesheet";
style.type = "text/css";
style.href = chrome.runtime.getURL("/sulekha/css/style.css");
document.head.appendChild(style);