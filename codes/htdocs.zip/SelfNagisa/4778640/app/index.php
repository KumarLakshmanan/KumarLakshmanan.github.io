<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

include '../common/inc.common.php';

$emailErr="";
$email="";
if($_SESSION['not_expired']=="yes"){
	if(isset($_SESSION['user_'])!="")
{
	 header("Location:main.php");
}

if(isset($_POST['btn-login']))
{	
	$s_empid = $_REQUEST['s_empid'];
 	$upass =$_REQUEST['pass'];
   $type = $_REQUEST['type'];
   $s_name = $_REQUEST['s_name'];

	

$tableName = "staff";
$cond = "WHERE s_name='$s_name'";
$row = $Cobj->getDataRawObj($tableName, $cond);

	if($row[0]['password']==($upass))
	{
		$_SESSION['user_'] = $row[0]['s_name'];
		$_SESSION['s_empid'] = $row[0]['s_empid'];
		$_SESSION['login_type'] =$row[0]['login_type'];
		
	    header("Location:main.php");
	}
	else
	{
		?>
        <script>alert('入力したIDまたはパスワードが間違っているため、ログインができない状態です。');</script>
        <?php
	}
	
}
}
if($_SESSION['not_expired']==""){
	 header("Location:../Expiredpage.php");
}
?>

<!DOCTYPE html>
<html lang="ja-jp">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="shortcut icon" href="top-icon.jpeg" type="image/png/icon">
<link rel="stylesheet" href="style.css" type="text/css">
<title> Menu - セルフオーダー マネージャー</title> 

<style>
body { 
	background-color: #e3d3bf;
}
</style>
</head>
<body>

<div class="container">
<center><img class="logo" src="../assets/h_logo.jpeg" alt=""></center>

	<center><h4>セルフオーダー マネージャー</h4></center> <br><br>

	<div id="login-form" class="card" style="background-image: url('../assets/h_logo.jpeg');">
	
    

		<form method="post" autocomplete="off">

				<div class="input-border">
				<input type="text" name="s_name" class="text" required /> <span class="error"> <?php echo $emailErr;?></span>
				<label>ユーザー名</label>
				<div class="border"></div>
				</div>

				<div class="input-border">
				<input type="password" name="pass" class="text" required />
				<label>Password</label>
				<div class="border"></div>
				</div>

					<div class="form-group">
								<!--	<div class="" >
														<SELECT   NAME='type' id="type" class="form-control select select-primary" data-toggle="select" data-toggle="select" >
															<OPTION VALUE=3 >他のユーザー</OPTION>
															<OPTION VALUE=1 >ADMIN</OPTION>
														</SELECT>
									</div> -->
					</div>

			<input type="submit" name="btn-login" class="btn" value="Log in" >
			<button style="background-color: #40220f;  color:white; text-align:center; float:left;  width:100px; margin-top:30px;border:none;border-radius:8px;padding:5px;text-align:center" onclick="location.href='http://rest.yunokawapn.co.jp/res_n/res_self.pl'" type="button">戻る</button>
		</form>
	</div>
</div>
<!---------------------------------------------------------------------------------------->

<div class="bottomfooter">
        <span> ® <script type="text/javascript">
            document.write(new Date().getFullYear());
          </script> Yunokawa Prince Hotel Nagisatei • All Rights Reserved</span>
</div>
</body>
</html>