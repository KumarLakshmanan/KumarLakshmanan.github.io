<?php 



function DateFormat($value)
{
	if($value != "0000-00-00" &&  !empty($value))	
		return date('d-m-Y', strtotime($value));
	else
		return "";
}

function YesNo($value)
{
    return ($value=="Y")?"Yes":"No";
}


?>