<?php 

error_reporting(E_ALL);
ini_set('display_errors','0');
ini_set('log_errors', '0');
$serverName = $_SERVER['SERVER_NAME'];
$docRoot = $_SERVER['DOCUMENT_ROOT'];

$gvDistId=1;
?>