<?php 

// $mdbhost = "localhost";
// $mdbname = "MenuNagisa";
// $mdbuser = "MenuNagisa";
// $mdbpass = "MenuNagisa";

$mdbhost = "localhost";
$mdbname = "menunagisa";
$mdbuser = "root";
$mdbpass = "";

$conn=mysqli_connect($mdbhost, $mdbuser,$mdbpass,$mdbname);
mysqli_query($conn, "SET NAMES 'UTF8'") or die("ERROR: ". mysqli_error($conn));

//to set up time when app can operate 
         date_default_timezone_set('Asia/Tokyo');
         $current = strtotime(date("H:i:s"));
        //  $four = strtotime('12:00:00');
        //  $ten = strtotime('21:00:00');
         $four = strtotime('00:00:00');
         $ten = strtotime('24:00:00');
        if($four <=$current && $current <= $ten){

                if ($conn->connect_error) {
                die("Connection failed: <br>" . $conn->connect_error);
                }
                //echo "Connected successfully to the database <b> MenuNagisa</b> <br>";
                mysqli_query($conn, "SET NAMES 'UTF8'") or die("ERROR: ". mysqli_error($con));


//the rest of code for "set up time when app can operate"
        } else{
          header('HTTP/1.1 405 Not Found');
          include '405.php'; 
          exit();
        }


?> 