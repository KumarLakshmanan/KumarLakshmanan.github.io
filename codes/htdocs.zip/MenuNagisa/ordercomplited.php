<?php

header('Content-Type: text/html; charset=utf-8');
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
session_start();

// Show error
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


include 'common/inc.common.php';
$sql = "select * from discount where active=1";
$disarr = $Cobj->union($sql);

$tableno = $_SESSION['tableno'];
$selectroom = $_SESSION['roomno'];
$selectguest = $_SESSION['guestname'];

$cdval2 = $_SESSION['CDVAL2'];
$qty = $_SESSION['QTY'];

if ($_SESSION['isStockDecreased'] == '1') {
    for ($i = 0; $i < count($cdval2); $i++) {
        $sql = "SELECT * FROM `drinks` WHERE CD2=" . $cdval2[$i] . " OR CD3=" . $cdval2[$i] . " OR CD4=" . $cdval2[$i] . " OR CD5=" . $cdval2[$i] . " OR CD6=" . $cdval2[$i];
        $stmt = $db->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $stock = $result[0]['stock_d'];
        $stocks = $stock - $qty[$i];
        $sql2 = "UPDATE `drinks` SET `stock_d`=" . $stocks . " WHERE CD2=" . $cdval2[$i] . " OR CD3=" . $cdval2[$i] . " OR CD4=" . $cdval2[$i] . " OR CD5=" . $cdval2[$i] . " OR CD6=" . $cdval2[$i];
        $stmt = $db->prepare($sql2);
        $stmt->execute();
    }
    $_SESSION['isStockDecreased'] = "0";
}

//To get IP and URL when an error accures
$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$useragent = $_SERVER['HTTP_USER_AGENT'];
$myip = $_SERVER['REMOTE_ADDR'];


//only if guest names are multiples
//no need to send error if r session is lost because guestname,table,room will be sent without any problem 
if (count($selectguest) > 1) {
    $file = fopen("log.txt", "a");
    $date = date('Y-m-d H:i:s');
    fwrite($file, "\n $date  Error : テーブル番号：部屋番号：お客様の名前 (Not Found) \n r = $r \n IP : ($myip) \n URL : $actual_link  \n スマホ情報: $useragent" . PHP_EOL . "--------------------------------------------------");
    fclose($file);
    header('HTTP/1.1 404 Not Found');
    include '404.php';
    exit();
}

?>



<!DOCTYPE html>
<html lang="ja-jp">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.9, maximum-scale=0.9, user-scalable=0">
    <meta name="theme-color" content="#c9ad86">
    <meta name="msapplication-navbutton-color" content="#c9ad86">
    <meta name="apple-mobile-web-app-status-bar-style" content="#c9ad86">

    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">

    <link rel="icon" href="images/top-icon.png">
    <link rel="stylesheet" href="css/main.css">

    <!-- W3 css -->
    <link rel="stylesheet" href="css/w3.css">

    <!-- jQuery library -->
    <script src="js/jquery-2-1-1.js"></script>


    <!-- <script src="script.js"></script> -->

    <script>
        function goBackto() {
            window.history.back();
        }
    </script>



    <title>Menu</title>
</head>

<body>
    <div class="mainmenu">


        <!--------------------cart------------------------>
        <div class="container" id="tow">

            <!--guest name and room number-->
            <div style="font-size:20px;text-align:center;">
                <p><?php echo $_SESSION['roomno']; ?> &nbsp;&nbsp;&nbsp; <?php echo $_SESSION['guestname'] . " 様"; ?></p>
            </div>
            <div style="text-align: center;"><span style="font-weight:900;font-size:20px"> ご注文ありがとうございます。</span><br><br> スタッフがお席までお持ちいたしますので今しばらくお待ちくださいませ。</div>


            <div class=" ">
                <button type="submit" class="roundedbutton center" id="roundedbutton" onClick="location.href='order01.php?r=<?php echo $_SESSION['r']; ?>'" value="注文履歴を見る" class="order-buttons checkout-btn">注文履歴を見る</button>
                <button type="submit" class="roundedbutton center" id="roundedbutton" style="margin-bottom: 30px;background-color:#dbb180; " onClick="location.href='bestof.php?r=<?php echo $_SESSION['r']; ?>'">戻る</button>


            </div>
        </div>

        <!------------------------------------------------------->

    </div>

    <div class="footer">

        <hr class="solid">
        <span style="color: #595143; font-size:8px"> ® <script type="text/javascript">
                document.write(new Date().getFullYear());
            </script> Yunokawa Prince Hotel Nagisatei • All Rights Reserved</span>
    </div>


</body>

</html>