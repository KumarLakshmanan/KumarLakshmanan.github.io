<?php
print phpinfo();
?>