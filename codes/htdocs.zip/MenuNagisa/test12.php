<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <!---------------------------------------------Framworks----------------------------------------------->
<!-- W3 css -->
<link rel="stylesheet" href="css/w3.css">

<!-- jQuery library -->
<script src="js/jquery-2-1-1.js"></script>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="css/bootstrap-4.5.3-dist/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="js/jquery-3-5-1.js"></script>

<!-- Popper JS -->
<script src="js/popper-1-16-0.js"></script>

<!-- Latest compiled JavaScript -->
<script src="css/bootstrap-4.5.3-dist/js/bootstrap.min.js"></script>
  <!----------------------------------------------------------------------------------------------------->

    <title>Document</title>
</head>
<body>
    


<center>






<?php
if(isset($_REQUEST['order'])){
    //$val=readfile("file.txt");
    //echo json_encode($val);
    
    $json = file_get_contents('file.txt');

//Decode JSON
$json_data = json_decode($json,true);
if (empty($json_data)) {
    echo "DATA EMPTY";
}
//Print data
//print_r($json_data);
else{ 
echo " <div class='container border mt-5 bg-light'>
    kamokuCD1=".$json_data['kamokuCD1']."
<br>kamokuCD2=".$json_data['kamokuCD2']." 
<br>kamokuName=".$json_data['kamokuName']."
<br>sisetuName=".$json_data['sisetuName']." 
<br>userName=".$json_data['userName']." 
<br>roomno=".$json_data['roomno']." 
<br>num=".$json_data['num']." 
<br>price=".$json_data['price']." 
<br>drinkFlg=".$json_data['drinkFlg']." 
<br>tableNo=".$json_data['tableNo']." 
<br>placeNo=".$json_data['placeNo']."
<br>userCD=".$json_data['userCD']."</div>"; 
 }

}

elseif($_POST['kamokuName']){
//file_put_contents("file.txt", $var);
$json = json_encode($_POST);
$res=explode(":" , $json);
file_put_contents("file.txt", $json);

//file_put_contents("file.txt", serialize($_POST));
}
else{
    echo "<div class='container mt-5'><div class='alert alert-danger '>
    <strong>Error!</strong> Check your URL and retry again
   </div></div>";

   echo "<div class='container mt-2'><div class='alert alert-success alert-dismissible'>
    <button type='button' class='close' data-dismiss='alert'>&times;</button>
    <strong>NOTE:</strong> Does the current URL match the following one? <br> http://172.20.100.125/MenuNagisa/test12.php?order 
   </div></div>";
   
    
}


?>
</center>
</body>
</html>
