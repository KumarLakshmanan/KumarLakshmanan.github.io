<?php

header('Content-Type: text/html; charset=utf-8');
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

session_start();
include 'common/inc.common.php';
$sql = "select * from discount where active=1";

$r= 633300;
$r = $_GET['r'];
$_SESSION['r'] = $r;

//Testing URL which data will come from
// $api = "http://rest.yunokawapn.co.jp/res_t/get_dec.pl?r=$r";

//the real URL which data will come from here
// $api = "http://rest.yunokawapn.co.jp/res_n/get_dec.pl?r=$r";

$request = curl_init($api); // initiate curl object
curl_setopt($request, CURLOPT_HEADER, 0); // set to 0 to eliminate header info from response
curl_setopt($request, CURLOPT_RETURNTRANSFER, 1); // Returns response data instead of TRUE(1)
//curl_setopt($request, CURLOPT_SSL_VERIFYPEER, FALSE); // uncomment if you get no gateway response using HTTPS
curl_setopt($request, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($request, CURLOPT_HTTPHEADER, array("Content-Type: application/x-www-form-urlencoded"));
$response = (string)curl_exec($request); // execute curl fetch and store results in $response

curl_close($request); // close curl object

$result = json_decode($response, true); // true turns it into an array


$response="12:333,555,666:MADIH,MADIH,DOI"; 
list($tableno, $roomno, $guestname) = explode(":", $response);
$tablenoarr = explode(",", $tableno);
$roomnoarr = explode(",", $roomno);
$guestnamearr = explode(",", $guestname);
$size = sizeof($roomnoarr);


//To get IP and URL when an error accures
$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$useragent=$_SERVER['HTTP_USER_AGENT'];
$myip = $_SERVER['REMOTE_ADDR']; 


// if guest information such as r value or table,roomno,guestname inside r value are not read
if ( empty($r) || empty($tableno) || empty($roomno) || empty($guestname) ) {
    $file = fopen("log.txt", "a");
    $date = date('Y-m-d H:i:s');
    fwrite($file, "\n $date  Error : テーブル番号：部屋番号：お客様の名前 (Not Found) \n r = $r \n IP : ($myip) \n URL : $actual_link  \n スマホ情報: $useragent" . PHP_EOL . "--------------------------------------------------"); 
    fclose($file);
    header('HTTP/1.1 404 Not Found');
    include '404.php';
    exit();
}

//for order history
$_SESSION['uniqueid'] = str_replace(",", "-", $roomno) . "-" . date('y-m-d');

if ($size > 1) {
?>


    <!DOCTYPE html>
    <html lang="ja-jp">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=0.9, maximum-scale=0.9, user-scalable=0">
        <meta name="theme-color" content="#c9ad86">
        <meta name="msapplication-navbutton-color" content="#c9ad86">
        <meta name="apple-mobile-web-app-status-bar-style" content="#c9ad86">

        <meta http-equiv="pragma" content="no-cache">
        <meta http-equiv="cache-control" content="no-cache">
        <meta http-equiv="expires" content="0">

        <link rel="icon" href="images/top-icon.png">
        <link rel="stylesheet" href="css/main.css">

        <!-- W3 css -->
        <link rel="stylesheet" href="css/w3.css">

        <!-- jQuery library -->
        <script src="js/jquery-2-1-1.js"></script>




        <title>Menu</title>


    </head>

    <body onload="history.replaceState('', '', 'index.php?r=<?php echo $_SESSION['r']; ?>')">
        <div class="containerPlus">


            <div>
                <img src="images/h_logo.jpeg" alt="" class="center">

                <p style="color: #595143; font-size:30px; text-align:center;margin-top:0; font-family:'Times New Roman', Times, serif">Drink Menu</p>

                <p style="color: #e88f3d;text-align:center;">お支払いされる方のお部屋番号を入力してください</p>
            </div>

            <div>
                <form action="menu01.php">
                    <input type="text" name="rnew" value="<?php echo $r; ?>" hidden id="rnew">
                    <select class="select_mate styroo " name="roomname" onclick="return false;" id="roomname" required>
                        <option value=""> お部屋番号を選択 </option>

                        <?php
                        for ($p = 0; $p < sizeof($roomnoarr); $p++) {
                            if ($tablenoarr[$p] > 0) {
                                $tb = $tablenoarr[$p];
                            } else {
                                $tb = $tablenoarr[0];
                            }
                            $rm = $roomnoarr[$p];
                            $gn = $guestnamearr[$p];
                            $val = $tb . "-" . $rm . "-" . $gn;

                            //if want to show guest name also and table change .$rm to $val
                            echo " <option value=" . $val . ">" . $rm . "</option>";
                        }
                        ?>
                    </select>
                    <div id="mydivi" hidden>
                        <p style="color: red;">お部屋番号をお選びください</p>
                    </div>
                    <!---部屋番号を入力してください。--->

                    <input type="button" class="roundedbutton" id="roundedbutton" value="TOPへ" onclick="update_session_value()" />
                </form>
            </div>

            <div class="footer">

                <hr class="solid">
                <span style="color: #595143; font-size:8px"> ® <script type="text/javascript">
                        document.write(new Date().getFullYear());
                    </script> Yunokawa Prince Hotel Nagisatei • All Rights Reserved</span>
            </div>

        </div>
    </body>

    </html>


<?php
} else {

    $_SESSION['guestname'] = $guestname;
    $_SESSION['tableno'] = $tableno;
    $_SESSION['roomno'] = $roomno;

    header("Location: bestof.php");
}
?>
<script>
    function update_session_value() {
        var value = document.getElementById('roomname').value;
        var rnew = document.getElementById('rnew').value;

        //alert(value);
        if ($(".select_mate").val() == "") {
            $("#mydivi").show();
        } else {

            $.ajax({
                type: "POST",
                url: 'session.php', // change url as your 
                data: 'select_amount=' + value,
                dataType: 'json',
                success: function(data) {

                    //alert();
                    if (data == 1) {
                        location.href = "bestof.php";
                    } else {}
                }
            });
        }
        //alert();

    }
</script>