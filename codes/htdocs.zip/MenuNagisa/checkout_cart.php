<?php
session_start();

header('Content-Type: text/html; charset=utf-8');
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
include 'common/inc.common.php';
$sql = "select * from discount where active=1";
$disarr = $Cobj->union($sql);


$tableno = $_SESSION['tableno'];
$roomno = $_SESSION['roomno'];
$guestname = $_SESSION['guestname'];

//to spererate rooms number and guests names
$pieces = explode(",", $roomno);
$namepieces = explode(",", $guestname);

//To get IP and URL when an error accures
$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$useragent = $_SERVER['HTTP_USER_AGENT'];
$myip = $_SERVER['REMOTE_ADDR'];

if (empty($tableno) || empty($roomno) || empty($guestname) || count($guestname) > 1) {
    $file = fopen("log.txt", "a");
    $date = date('Y-m-d H:i:s');
    fwrite($file, "\n $date  Error : テーブル番号：部屋番号：お客様の名前 (Not Found) \n r = $r \n IP : ($myip) \n URL : $actual_link \n スマホ情報: $useragent " . PHP_EOL . "--------------------------------------------------");
    fclose($file);
    header('HTTP/1.1 404 Not Found');
    include '404.php';
    exit();
}

?>



<!DOCTYPE html>
<html lang="ja-jp">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.9, maximum-scale=0.9, user-scalable=0">
    <meta name="theme-color" content="#c9ad86">
    <meta name="msapplication-navbutton-color" content="#c9ad86">
    <meta name="apple-mobile-web-app-status-bar-style" content="#c9ad86">

    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">

    <link rel="icon" href="images/top-icon.png">
    <link rel="stylesheet" href="css/main.css">

    <!-- W3 css -->
    <link rel="stylesheet" href="css/w3.css">

    <!-- jQuery library -->
    <script src="js/jquery-2-1-1.js"></script>


    <script type='text/javascript'>
        $(document).ready(function() {
            $("#cartform").submit(function(e) {
                // disable the submit button
                $("#orderBtn").attr("disabled", true);
                $("#orderBtn").val("Ordering...");

                var ver = "";
                e.preventDefault(e);
                $('#loading').show();

                var a = $(".item-count").length; // alert(string);
                if (a < 1) {
                    alert("飲み物を選んでもう一度お試しください。");
                } else {
                    $.ajax({
                        url: "addorderInfo.php",
                        type: "POST",
                        data: new FormData(this),
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function(data) {
                            data = data.trim();
                            if (data == "success") {
                                window.location.href = "ordercomplited.php";
                                $("#clearcart").click();
                            } else {
                                window.location.href = '404.php';
                                $("#clearcart").click();
                            }
                            var isAjaxSended = false;
                        },
                        error: function(error, exception) {
                            window.location.href = '404.php';
                            $("#clearcart").click();
                            var isAjaxSended = false;
                        }
                    });
                }
            });
        });

        function goBackto() {
            window.history.back();
        }
    </script>



    <title>Menu</title>
</head>

<body onload="history.replaceState('', '', 'bestof.php?r=<?php echo $_SESSION['r']; ?>')">
    <div class="mainmenu">


        <!--------------------cart------------------------>
        <div class="container" id="tow">

            <!--guest name and room number-->
            <div style="font-size:20px;text-align:center;">
                <p><?php echo $_SESSION['roomno']; ?> &nbsp;&nbsp;&nbsp; <?php echo $_SESSION['guestname'] . " 様"; ?></p>
            </div>

            <div style="text-align: center;font-weight:900;font-size:20px"> カート内は <span class="total-count"></span> 点のアイテムがあります</div>

            <div style="border-top:1px solid black;margin-top:15px;margin-bottom:10px;"></div>


            <div class="">

                <!--button to clear cart (hidden)-->
                <button class="clear-cart btn btn-danger order-buttons" id="clearcart" style="display:none">すべて削除 <img src="images/trash-black.png" alt=""> </button>

                <form action="" method="POST" name="cartform" id="cartform">

                    <div>
                        <?php
                        echo "<input type='text' name='selectroom' value='" . $pieces[0] . "' hidden>";
                        echo "<input type='text' name='selectguest' value='" . $namepieces[0] . "' hidden>";
                        ?>
                    </div>

                    <input type="text" name="minus" value="minus" hidden>
                    <input type="text" name="roomno" value="<?php echo $roomno; ?>" hidden>
                    <input type="text" name="tableno" value="<?php echo $tableno; ?>" hidden>

                    <div class="modal fade" id="cart" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                                <div class="modal-header"></div>
                                <div class="modal-body">
                                    <table class="show-cart table">
                                        <!---set up in JS side---->
                                    </table>
                                    <?php if ($disarr[0]['discount_name'] == "なし") {
                                    } else {

                                        echo  "<div style='text-align: center;color:red'> " . $disarr[0]['discount_name'] . " </div>";
                                    } ?>



                                    <?php if ($disarr[0]['discount_name'] == "なし") {
                                        echo "<div> <p style='display:inline-block;'> 合計金額</p><input type='text' name='finaltot' id='finaltot' readonly  value=''>円 ";
                                        echo " <input  type='text' name='discper' id='discper' readonly hidden value='" . $disarr[0]['disc_per'] . "'> </div> ";
                                    } else {
                                        echo "<div> <p style='display:inline-block;left:20%'> 合計金額</p><input style='color:red;font-weight:400' type='text' name='finaltot' id='finaltot' readonly  value=''>円 ";
                                        echo " <input  type='text' name='discper' id='discper' readonly hidden value='" . $disarr[0]['disc_per'] . "'> </div> ";
                                    } ?>


                                    <p style="text-align: center;font-weight:900"> ご注文はまだ確定しておりません。<br>
                                        よろしければ「注文する」を選択してください。</p>



                                </div>


                                <div class="send-order">
                                    <button type="submit" name="submission" class="roundedbutton center" id="orderBtn" value="注文する" class="order-buttons checkout-btn">注文する</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <button type="submit" class="roundedbutton center" style="margin-bottom: 30px;background-color:#dbb180; " onClick="location.href='bestof.php?r=<?php echo $_SESSION['r']; ?>'">戻る</button>
            </div>

        </div>

    </div>
    <!-------------------------mainmenu div ends here------------------------------>
    <div class="footer">
        <hr class="solid">
        <span style="color: #595143; font-size:8px"> ® <script type="text/javascript">
                document.write(new Date().getFullYear());
            </script> Yunokawa Prince Hotel Nagisatei • All Rights Reserved</span>
    </div>

    <script src="js/main.js"></script>


</body>

</html>