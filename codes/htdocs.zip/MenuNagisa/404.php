<?php

header('Content-Type: text/html; charset=utf-8');
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");


?>

<!--<?php echo $_SERVER['REQUEST_URI']; ?> does not exist, sorry.<br> -->

<!DOCTYPE html>
<html lang="ja-jp">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=0.9, maximum-scale=0.9, user-scalable=0">

  <meta name="theme-color" content="#c9ad86">
  <meta name="msapplication-navbutton-color" content="#c9ad86">
  <meta name="apple-mobile-web-app-status-bar-style" content="#c9ad86">

  <meta http-equiv="pragma" content="no-cache">
  <meta http-equiv="cache-control" content="no-cache">
  <meta http-equiv="expires" content="0">

  <link rel="icon" href="images/top-icon.png">
  <link rel="stylesheet" href="css/main.css">

  <!-- W3 css -->
  <link rel="stylesheet" href="css/w3.css">

  <!-- jQuery library -->
  <script src="js/jquery-2-1-1.js"></script>

  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="css/bootstrap-4.5.3-dist/css/bootstrap.min.css">

  <!-- jQuery library -->
  <script src="js/jquery-3-5-1.js"></script>

  <!-- Popper JS -->
  <script src="js/popper-1-16-0.js"></script>

  <!-- Latest compiled JavaScript -->
  <script src="css/bootstrap-4.5.3-dist/js/bootstrap.min.js"></script>


  <title>Menu</title>

  <style>
    .containerr {
      position: relative;
    }

    .outofstock {
      filter: alpha(opacity=40);
      /* msie */
    }

    /* Centered text */
    .centered {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      font-size: 30px;
      background-color: #b39c86;
      border-radius: 12px;
      padding-left: 8px;
      padding-right: 8px;
    }
  </style>

</head>

<body style="background-color: #e3d3bf;">
  <div class="containerPlus2">
    <img style="width:384px;height:auto;" src="images/kiridashi8/404.jpeg" usemap="#image-map">

  </div>


</body>

</html>