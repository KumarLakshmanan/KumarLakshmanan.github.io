<?php
session_start();

header('Content-Type: text/html; charset=utf-8');
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
if (isset($_SESSION['guestname']) and $_SESSION['guestname'] != "") {

  include 'common/inc.common.php';

  $sql = "select * from drinks WHERE stock !='none' order by menus,position";
  $dataarr = $Cobj->union($sql);

  $sql = "select * from discount where active=1";
  $disarr = $Cobj->union($sql);

  //print_r($dataarr); exit;

  //shows best drinks from all the time
  //$sql = "SELECT drinks.*,confirmedorders.cd2,SUM(productquantity) AS `value_occurrence` from confirmedorders JOIN drinks on confirmedorders.CD2 = drinks.CD2 GROUP BY confirmedorders.cd2 ORDER BY `value_occurrence` DESC LIMIT 3 ";

  //shows best drinks within the same day
  $todaydate = date('Y-m-d');
  $sql = "SELECT drinks.*,confirmedorders.cd2,confirmedorders.updated ,SUM(productquantity) AS `value_occurrence` from confirmedorders JOIN drinks on confirmedorders.CD2 = drinks.CD2 or confirmedorders.CD2 = drinks.CD3 or confirmedorders.CD2 = drinks.CD4 or confirmedorders.CD2 = drinks.CD5 or confirmedorders.CD2 = drinks.CD6  where drinks.stock !='none' and confirmedorders.updated LIKE '$todaydate%' GROUP BY drinks.d_refid ORDER BY `value_occurrence` DESC LIMIT 3 ";
  $bestDrinks = $Cobj->union($sql);

  //session variables 
  $r = $_SESSION['r'];
  $tableno = $_SESSION['tableno'];
  $selectroom = $_SESSION['roomno'];
  $selectguest = $_SESSION['guestname'];


  //To get IP and URL when an error accures
  $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
  $useragent = $_SERVER['HTTP_USER_AGENT'];
  $myip = $_SERVER['REMOTE_ADDR'];

  // if guest information such as r value or table,roomno,guestname inside r value are not available or double entred
  if (empty($tableno) || empty($selectroom) || empty($selectguest) || count($selectguest) > 1) {
    $file = fopen("log.txt", "a");
    $date = date('Y-m-d H:i:s');
    fwrite($file, "\n $date  Error : テーブル番号：部屋番号：お客様の名前 (Not Found) \n r = $r \n IP : ($myip) \n URL : $actual_link  \n スマホ情報: $useragent" . PHP_EOL . "--------------------------------------------------");
    fclose($file);
    header('HTTP/1.1 404 Not Found');
    include '404.php';
    exit();
  }


?>

  <!DOCTYPE html>
  <html lang="ja-jp">

  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.9, maximum-scale=0.9, user-scalable=0">

    <meta name="theme-color" content="#c9ad86">
    <meta name="msapplication-navbutton-color" content="#c9ad86">
    <meta name="apple-mobile-web-app-status-bar-style" content="#c9ad86">

    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">

    <link rel="icon" href="images/top-icon.png">
    <link rel="stylesheet" href="css/main.css">

    <!-- W3 css -->
    <link rel="stylesheet" href="css/w3.css">

    <!-- jQuery library -->
    <script src="js/jquery-2-1-1.js"></script>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="css/bootstrap-4.5.3-dist/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="js/jquery-3-5-1.js"></script>

    <!-- Popper JS -->
    <script src="js/popper-1-16-0.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="css/bootstrap-4.5.3-dist/js/bootstrap.min.js"></script>

    <title>Menu</title>


  </head>

  <body onload="history.replaceState('', '', 'index.php?r=<?php echo $_SESSION['r']; ?>')" style="background-color: #e3d3bf;">

    <div class="containerPlus2">

      <!----------------------------------Top Menu------------------------------------->
      <div class="fixme">
        <!--cart's floating quantity button-->
        <div style="position: absolute; right:15px;top:53px">
          <button class="button2 button1-color" onclick="location.href='checkout_cart.php';"> <span class="total-count"></span> </button> <br>
          <input type="text" name="discper" id="discper" hidden readonly value="<?php echo $disarr[0]['disc_per']; ?>">
          <input type="text" name="finaltot" id="finaltot" readonly="" value="" hidden>
        </div>

        <img style="width: 384px; height:120px;" src="images/cutout/top-menu.jpeg" usemap="#image-map">
        <map name="image-map" style="cursor: pointer;">

          <!--guest name and room number-->
          <div class="top-left-room">
            <p><?php echo $_SESSION['roomno']; ?></p>
          </div>
          <div class="top-left-guest">
            <p><?php echo $_SESSION['guestname']; ?></p>
          </div>

          <!--Change User-->
          <area target="" alt="" title="" href="bestof.php?r=<?php echo $_SESSION['r']; ?>" coords="1,60,95,115" shape="rect">

          <!--Home-->
          <area target="" alt="" title="" href="index.php?r=<?php echo $_SESSION['r']; ?>" coords="98,60,190,115" shape="rect">

          <!--History-->
          <area target="" alt="" title="" href="order01.php?r=<?php echo $_SESSION['r']; ?>" coords="193,60,286,115" shape="rect">

          <!--Cart-->
          <area target="" alt="" title="" href="checkout_cart.php" coords="289,60,382,115" shape="rect">


        </map>
      </div>
      <!----------------------------------- Mid-Top Menu ------------------------------>
      <div class="midmenu">
        <img style="width: 384px; height:auto" src="images/cutout/mid-menu.jpeg" usemap="#image-map2">
        <map name="image-map2" style="cursor: pointer;">
          <!-- Best of -->
          <area target="" alt="" title="" class="tablinks" onclick="openCity(event, 'menu00')" coords="" shape="rect">

          <!-- オリジナルボトル -->
          <area target="" alt="" title="" class="tablinks" onclick="openCity(event, 'menu01')" coords="2,2,126,110" shape="rect">


          <!-- 日本酒　。焼酎 -->
          <area target="" alt="" title="" class="tablinks" onclick="openCity(event, 'menu02')" coords="130,2,255,110" shape="rect">

          <!--ビール　。ウイスキー　-->
          <area target="" alt="" title="" class="tablinks" onclick="openCity(event, 'menu03')" coords="258,2,382,110" shape="rect">




          <!-- サワー　。　果実酒　-->
          <area target="" alt="" title="" class="tablinks" onclick="openCity(event, 'menu04')" coords="2,112,126,284" shape="rect">

          <!--ワイン-->
          <area target="" alt="" title="" class="tablinks" onclick="openCity(event, 'menu05')" coords="130,112,255,284" shape="rect">

          <!--ソフトドリンク-->
          <area target="" alt="" title="" class="tablinks" onclick="openCity(event, 'menu06')" coords="258,112,382,284" shape="rect">
        </map>
      </div>

      <!------------------------------------------------------------------------------>

      <!--show best of drinks only when 3 drinks are available and after 18:30 -->
      <?php

      date_default_timezone_set('Asia/Tokyo');
      $current = strtotime(date("H:i:s"));
      $fromtime = strtotime('00:00:00');
      $totime = strtotime('24:00:00');
    
      if (!empty($bestDrinks) && count($bestDrinks) >= 3 && $fromtime <= $current && $current <= $totime) {

      ?>

        <!--button to go to cheap drinks page-->
        <!-- <button onclick="topFunction()" id="cheapdrink" title="">安い<img src="images/cutout/flame.jpeg" alt=""></button> -->

        <!----------------------------------best of --------------------------------->

        <div id="menu00" class="tabcontent">
          <img style="width: 384px; height:auto;" src="images/cutout/bestof.jpeg" alt="" usemap="#m00">

          <!------------------------------Best of No 1----------------------------->

          <img style="width: 384px; height:auto;" src="images/cutout/asset109.jpeg" alt="">

          <?php
          $staffcom = $bestDrinks[0]['drinkinfo'];
          $stockd = $bestDrinks[0]['stock_d'];

          if ($stockd <= 0 && $stockd > -100) {
            echo "<div class='containerr'><img style='width: 384px; height:auto;' src='upload/" . $bestDrinks[0]['productimage'] . "' usemap='#m01'  title='Out of stock'  class='outofstock' ><div class='centered'> SOLD OUT </div></div>";
          } else {

            //show drinkinfo form table drinks if available
            if (empty($staffcom)) {
              //echo   "<img style='width: 384px; height:auto; position:relative;' src='upload/".$bestDrinks[0]['productimage']."' usemap='#m01".$stk."' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialogg".$bestDrinks[0]['d_refid']."' onclick='calval(".$bestDrinks[0]['d_refid'].")'></div>";
              echo "<img style='width: 384px; height:auto;' src='upload/" . $bestDrinks[0]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialogg" . $bestDrinks[0]['d_refid'] . "' onclick='calval(" . $bestDrinks[0]['d_refid'] . ")'>";
            } else {
              echo "<div style='position:relative;'><div data-toggle='modal' data-target='#bd-example-modal-sm0' id='staffrecom' style='position:absolute;'> <img src='images/cutout/comment.jpeg'> </div> <img style='width: 384px; height:auto;position:'relative;' src='upload/" . $bestDrinks[0]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialogg" . $bestDrinks[0]['d_refid'] . "' onclick='calval(" . $bestDrinks[0]['d_refid'] . ")'></div>";
            }
          ?>
            <!----staff comment info modal------>
            <!-- Modal -->
            <div class="modal fade" id="bd-example-modal-sm0" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <!-- <div class="modal-header"> -->
                  <div class="modal-body">
                    <h5><img src="images/cutout/steward.jpeg" alt=""> <br> <?php echo $bestDrinks[0]['drinkinfo']; ?></h5>
                  </div>
                  <!-- </div> -->

                </div>
              </div>
            </div>

            <!----- check database and import drinks here------>
            <div id="addBookDialogg<?php echo $bestDrinks[0]['d_refid']; ?>" class="modal fade" role="dialog">
              <div class="modal-dialog modal-dialog-centered" style="width: 350px; margin-left:auto; margin-right:auto;">

                <!-- Modal content-->
                <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                  <!--close button-->
                  <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->

                  <form id="form<?php echo $bestDrinks[0]['d_refid']; ?>" action="#" method="GET">
                    <input type="text" hidden value="<?php echo $selectroom; ?>" name="selectroom">
                    <input type="text" hidden value="<?php echo $selectguest; ?>" name="selectguest">
                    <input type="text" hidden value="<?php echo $tableno; ?>" name="tableno">
                    <input type="text" readonly hidden value="<?php echo $bestDrinks[0]['product']; ?>" name="prd_name">

                    <div class="modal-body">

                      <div class="form-group">
                        <div class="modal-dialog modal-sm">
                          <div class="modal-content" style="background-color: #e3d3bf;">

                            <input type="text" value="0hgjhgjgjg" id="price<?php echo $bestDrinks[0]['d_refid']; ?>" readonly hidden>

                            <?php

                            if ($bestDrinks[0]['CD3'] != 0 or $bestDrinks[0]['CD4'] != 0 or $bestDrinks[0]['CD5'] != 0 or $bestDrinks[0]['CD6'] != 0) {
                              echo "<h5 class='question1'>飲み方を選んでください。</h5>";
                              if ($bestDrinks[0]['CD3'] != 0) {
                                echo "<h4 class='mr-auto' style='margin-left:30px;'><input class='radios' id='ストレート" . $bestDrinks[0]['CD3'] . "'  type='radio' name='b_radio_" . $bestDrinks[0]['d_refid'] . "' value='" . $bestDrinks[0]['CD3'] . "'><label style='color:black;' for='ストレート" . $bestDrinks[0]['CD3'] . "'>ストレート</label></h4> &nbsp";
                              }
                              if ($bestDrinks[0]['CD4'] != 0) {
                                echo "<h4 class='mr-auto' style='margin-left:30px;'><input class='radios' id='ロック" . $bestDrinks[0]['CD4'] . "'  type='radio' name='b_radio_" . $bestDrinks[0]['d_refid'] . "' value='" . $bestDrinks[0]['CD4'] . "'><label style='color:black;' for='ロック" . $bestDrinks[0]['CD4'] . "'>ロック</label></h4> ";
                              }
                              if ($bestDrinks[0]['CD5'] != 0) {
                                echo "<h4 class='mr-auto' style='margin-left:30px;'><input class='radios' id='水割り" . $bestDrinks[0]['CD5'] . "'  type='radio' name='b_radio_" . $bestDrinks[0]['d_refid'] . "' value='" . $bestDrinks[0]['CD5'] . "'><label style='color:black;' for='水割り" . $bestDrinks[0]['CD5'] . "'>水割り</label></h4> ";
                              }
                              if ($bestDrinks[0]['CD6'] != 0) {
                                echo "<h4 class='mr-auto' style='margin-left:30px;'><input class='radios' id='お湯割り" . $bestDrinks[0]['CD6'] . "'  type='radio' name='b_radio_" . $bestDrinks[0]['d_refid'] . "' value='" . $bestDrinks[0]['CD6'] . "'><label style='color:black;' for='お湯割り" . $bestDrinks[0]['CD6'] . "'>お湯割り</label></h4> ";
                              }
                            }
                            if ($bestDrinks[0]['drinktype'] == "ボトル") {
                              $random = rand(10000000, 99999999);
                            ?>
                              <!-----hide counter to add glass----->
                              <div style="display: none;">
                                <h5>
                                  <div class="chooseGlass">お使いのグラスの数を入力してください。</div>
                                </h5>
                                <div class='counter'>
                                  <a onclick="decrement('counter_<?php echo $bestDrinks[0]['d_refid'];
                                                                  echo $random; ?>')" class='counter-button'>-</a>
                                  <input type='text' id='counter_<?php echo $bestDrinks[0]['d_refid'];
                                                                  echo $random; ?>' value='1' class='counter-value' name='glassCount' readonly>
                                  <a onclick="increment('counter_<?php echo $bestDrinks[0]['d_refid'];
                                                                  echo $random; ?>')" class='counter-button'>+</a>
                                </div>
                              </div>
                            <?php
                            }
                            ?>
                            <h5 class="question1"><?php echo $bestDrinks[0]['product'] . 'をカートに追加してよろしいですか' ?></h5>

                          </div>
                        </div>
                      </div>

                      <?php if ($bestDrinks[0]['CD3'] != 0 or $bestDrinks[0]['CD4'] != 0 or $bestDrinks[0]['CD5'] != 0 or $bestDrinks[0]['CD6'] != 0) { ?>
                        <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $bestDrinks[0]['product'] ?>" data-price="<?php echo $bestDrinks[0]['price'] ?>" value="Ok" id="<?php echo $bestDrinks[0]['d_refid']; ?>" onclick="beforeCallCart(<?php echo $bestDrinks[0]['d_refid']; ?>,<?php echo $bestDrinks[0]['CD1']; ?>,<?php echo $random ?> '',true),clearcheckbox()">
                      <?php } else { ?>
                        <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $bestDrinks[0]['product'] ?>" data-price="<?php echo $bestDrinks[0]['price'] ?>" value="Ok" id="<?php echo $bestDrinks[0]['d_refid']; ?>" onclick="callcartoriginal(<?php echo $bestDrinks[0]['d_refid']; ?>,<?php echo $bestDrinks[0]['CD1']; ?>,<?php echo $bestDrinks[0]['CD2']; ?>,<?php echo $random ?>)">
                      <?php } ?>

                    </div>

                  </form>

                  <button type="button" class="roundedbuttonnava" data-dismiss="modal">キャンセル</button>

                </div>



              </div>
            </div>
          <?php
          }
          ?>


          <!------------------------------Best of No 2------------------------------>

          <img style="width: 384px; height:auto;" src="images/cutout/asset108.jpeg" alt="">


          <?php
          $staffcom = $bestDrinks[1]['drinkinfo'];
          $stockd = $bestDrinks[1]['stock_d'];

          if ($stockd <= 0 && $stockd > -100) {
            echo "<div class='containerr'><img style='width: 384px; height:auto;' src='upload/" . $bestDrinks[1]['productimage'] . "' usemap='#m01'  title='Out of stock'  class='outofstock' ><div class='centered'> SOLD OUT </div></div>";
          } else {

            //show drinkinfo form table drinks if available
            if (empty($staffcom)) {
              //echo   "<img style='width: 384px; height:auto; position:relative;' src='upload/".$bestDrinks[0]['productimage']."' usemap='#m01".$stk."' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialogg".$bestDrinks[0]['d_refid']."' onclick='calval(".$bestDrinks[0]['d_refid'].")'></div>";
              echo "<img style='width: 384px; height:auto;' src='upload/" . $bestDrinks[1]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialogg" . $bestDrinks[1]['d_refid'] . "' onclick='calval(" . $bestDrinks[1]['d_refid'] . ")'>";
            } else {
              echo "<div style='position:relative;'><div data-toggle='modal' data-target='#bd-example-modal-sm1' id='staffrecom' style='position:absolute;'> <img src='images/cutout/comment.jpeg'> </div> <img style='width: 384px; height:auto;position:'relative;' src='upload/" . $bestDrinks[1]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialogg" . $bestDrinks[1]['d_refid'] . "' onclick='calval(" . $bestDrinks[1]['d_refid'] . ")'></div>";
            }
          ?>
            <!----staff comment info modal------>
            <!-- Modal -->
            <div class="modal fade" id="bd-example-modal-sm1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <!-- <div class="modal-header"> -->
                  <div class="modal-body">
                    <h5><img src="images/cutout/steward.jpeg" alt=""> <br> <?php echo $bestDrinks[1]['drinkinfo']; ?></h5>
                  </div>
                  <!-- </div> -->

                </div>
              </div>
            </div>
            <!----- check database and import here------>
            <div id="addBookDialogg<?php echo $bestDrinks[1]['d_refid']; ?>" class="modal fade" role="dialog">
              <div class="modal-dialog modal-dialog-centered" style="width: 350px; margin-left:auto; margin-right:auto;">

                <!-- Modal content-->
                <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                  <!--close button-->
                  <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->

                  <form id="form<?php echo $bestDrinks[1]['d_refid']; ?>" action="#" method="GET">
                    <input type="text" hidden value="<?php echo $selectroom; ?>" name="selectroom">
                    <input type="text" hidden value="<?php echo $selectguest; ?>" name="selectguest">
                    <input type="text" hidden value="<?php echo $tableno; ?>" name="tableno">
                    <input type="text" readonly hidden value="<?php echo $bestDrinks[1]['product']; ?>" name="prd_name">


                    <div class="modal-body">

                      <div class="form-group">
                        <div class="modal-dialog modal-sm">
                          <div class="modal-content" style="background-color: #e3d3bf;">

                            <input type="text" value="0hgjhgjgjg" id="price<?php echo $bestDrinks[1]['d_refid']; ?>" readonly hidden>

                            <?php

                            if ($bestDrinks[1]['CD3'] != 0 or $bestDrinks[1]['CD4'] != 0 or $bestDrinks[1]['CD5'] != 0 or $bestDrinks[1]['CD6'] != 0) {
                              echo "<h5 class='question1'>飲み方を選んでください。</h5>";
                              if ($bestDrinks[1]['CD3'] != 0) {
                                echo "<h4 class='mr-auto' style='margin-left:30px;'><input class='radios' id='ストレート" . $bestDrinks[1]['CD3'] . "'  type='radio' name='b_radio_" . $bestDrinks[1]['d_refid'] . "' value='" . $bestDrinks[1]['CD3'] . "'><label style='color:black;' for='ストレート" . $bestDrinks[1]['CD3'] . "'>ストレート</label></h4> &nbsp";
                              }
                              if ($bestDrinks[1]['CD4'] != 0) {
                                echo "<h4 class='mr-auto' style='margin-left:30px;'><input class='radios' id='ロック" . $bestDrinks[1]['CD4'] . "'  type='radio' name='b_radio_" . $bestDrinks[1]['d_refid'] . "' value='" . $bestDrinks[1]['CD4'] . "'><label style='color:black;' for='ロック" . $bestDrinks[1]['CD4'] . "'>ロック</label></h4> ";
                              }
                              if ($bestDrinks[1]['CD5'] != 0) {
                                echo "<h4 class='mr-auto' style='margin-left:30px;'><input class='radios' id='水割り" . $bestDrinks[1]['CD5'] . "'  type='radio' name='b_radio_" . $bestDrinks[1]['d_refid'] . "' value='" . $bestDrinks[1]['CD5'] . "'><label style='color:black;' for='水割り" . $bestDrinks[1]['CD5'] . "'>水割り</label></h4> ";
                              }
                              if ($bestDrinks[1]['CD6'] != 0) {
                                echo "<h4 class='mr-auto' style='margin-left:30px;'><input class='radios' id='お湯割り" . $bestDrinks[1]['CD6'] . "'  type='radio' name='b_radio_" . $bestDrinks[1]['d_refid'] . "' value='" . $bestDrinks[1]['CD6'] . "'><label style='color:black;' for='お湯割り" . $bestDrinks[1]['CD6'] . "'>お湯割り</label></h4> ";
                              }
                            }
                            if ($bestDrinks[1]['drinktype'] == "ボトル") {
                              $random = rand(10000000, 99999999);
                            ?>
                              <!-----hide counter to add glass----->
                              <div style="display: none;">
                                <h5>
                                  <div class="chooseGlass">お使いのグラスの数を入力してください。</div>
                                </h5>
                                <div class='counter'>
                                  <a onclick="decrement('counter_<?php echo $bestDrinks[1]['d_refid'];
                                                                  echo $random ?>')" class='counter-button'>-</a>
                                  <input type='text' id='counter_<?php echo $bestDrinks[1]['d_refid'];
                                                                  echo $random ?>' value='1' class='counter-value' name='glassCount' readonly>
                                  <a onclick="increment('counter_<?php echo $bestDrinks[1]['d_refid'];
                                                                  echo $random ?>')" class='counter-button'>+</a>
                                </div>
                              </div>
                            <?php
                            }
                            ?>

                            <h5 class="question1"><?php echo $bestDrinks[1]['product'] . 'をカートに追加してよろしいですか' ?></h5>

                          </div>
                        </div>
                      </div>
                      <?php if ($bestDrinks[1]['CD3'] != 0 or $bestDrinks[1]['CD4'] != 0 or $bestDrinks[1]['CD5'] != 0 or $bestDrinks[1]['CD6'] != 0) { ?>
                        <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $bestDrinks[1]['product'] ?>" data-price="<?php echo $bestDrinks[1]['price'] ?>" value="Ok" id="<?php echo $bestDrinks[1]['d_refid']; ?>" onclick="beforeCallCart(<?php echo $bestDrinks[1]['d_refid']; ?>,<?php echo $bestDrinks[1]['CD1']; ?>,<?php echo $random ?>'',true),clearcheckbox()">
                      <?php } else { ?>
                        <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $bestDrinks[1]['product'] ?>" data-price="<?php echo $bestDrinks[1]['price'] ?>" value="Ok" id="<?php echo $bestDrinks[1]['d_refid']; ?>" onclick="callcartoriginal(<?php echo $bestDrinks[1]['d_refid']; ?>,<?php echo $bestDrinks[1]['CD1']; ?>,<?php echo $bestDrinks[1]['CD2']; ?>,<?php echo $random ?>)">
                      <?php } ?>
                    </div>
                  </form>

                  <button type="button" class="roundedbuttonnava" data-dismiss="modal">キャンセル</button>

                </div>

              </div>
            </div>


          <?php
          }
          ?>


          <!-----------------------------Best of No 3-------------------------------->

          <img style="width: 384px; height:auto;" src="images/cutout/asset107.jpeg" alt="">

          <?php
          $staffcom = $bestDrinks[2]['drinkinfo'];
          $stockd = $bestDrinks[2]['stock_d'];

          if ($stockd <= 0 && $stockd > -100) {
            echo "<div class='containerr'><img style='width: 384px; height:auto;' src='upload/" . $bestDrinks[2]['productimage'] . "' usemap='#m01'  title='Out of stock'  class='outofstock' ><div class='centered'> SOLD OUT </div></div>";
          } else {

            //show drinkinfo form table drinks if available
            if (empty($staffcom)) {
              //echo   "<img style='width: 384px; height:auto; position:relative;' src='upload/".$bestDrinks[0]['productimage']."' usemap='#m01".$stk."' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialogg".$bestDrinks[0]['d_refid']."' onclick='calval(".$bestDrinks[0]['d_refid'].")'></div>";
              echo "<img style='width: 384px; height:auto;' src='upload/" . $bestDrinks[2]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialogg" . $bestDrinks[2]['d_refid'] . "' onclick='calval(" . $bestDrinks[2]['d_refid'] . ")'>";
            } else {
              echo "<div style='position:relative;'><div data-toggle='modal' data-target='#bd-example-modal-sm2' id='staffrecom' style='position:absolute;'> <img src='images/cutout/comment.jpeg'> </div> <img style='width: 384px; height:auto;position:'relative;' src='upload/" . $bestDrinks[2]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialogg" . $bestDrinks[2]['d_refid'] . "' onclick='calval(" . $bestDrinks[2]['d_refid'] . ")'></div>";
            }
          ?>
            <!----staff comment info modal------>
            <!-- Modal -->
            <div class="modal fade" id="bd-example-modal-sm2" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <!-- <div class="modal-header"> -->
                  <div class="modal-body">
                    <h5><img src="images/cutout/steward.jpeg" alt=""> <br> <?php echo $bestDrinks[2]['drinkinfo']; ?></h5>
                  </div>
                  <!-- </div> -->

                </div>
              </div>
            </div>

            <!----- check database and import here------>
            <div id="addBookDialogg<?php echo $bestDrinks[2]['d_refid']; ?>" class="modal fade" role="dialog">
              <div class="modal-dialog modal-dialog-centered" style="width: 350px; margin-left:auto; margin-right:auto;">

                <!-- Modal content-->
                <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                  <!--close button-->
                  <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->

                  <form id="form<?php echo $bestDrinks[2]['d_refid']; ?>" action="#" method="GET">
                    <input type="text" hidden value="<?php echo $selectroom; ?>" name="selectroom">
                    <input type="text" hidden value="<?php echo $selectguest; ?>" name="selectguest">
                    <input type="text" hidden value="<?php echo $tableno; ?>" name="tableno">
                    <input type="text" readonly hidden value="<?php echo $bestDrinks[2]['product']; ?>" name="prd_name">


                    <div class="modal-body">

                      <div class="form-group">
                        <div class="modal-dialog modal-sm">
                          <div class="modal-content" style="background-color: #e3d3bf;">

                            <input type="text" value="0hgjhgjgjg" id="price<?php echo $bestDrinks[2]['d_refid']; ?>" readonly hidden>

                            <?php

                            if ($bestDrinks[2]['CD3'] != 0 or $bestDrinks[2]['CD4'] != 0 or $bestDrinks[2]['CD5'] != 0 or $bestDrinks[2]['CD6'] != 0) {
                              echo "<h5 class='question1'>飲み方を選んでください。</h5>";
                              if ($bestDrinks[2]['CD3'] != 0) {
                                echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ストレート" . $bestDrinks[2]['CD3'] . "'  type='radio' name='b_radio_" . $bestDrinks[2]['d_refid'] . "' value='" . $bestDrinks[2]['CD3'] . "'><label style='color:black;' for='ストレート" . $bestDrinks[2]['CD3'] . "'>ストレート</label></h4> &nbsp";
                              }
                              if ($bestDrinks[2]['CD4'] != 0) {
                                echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ロック" . $bestDrinks[2]['CD4'] . "'  type='radio' name='b_radio_" . $bestDrinks[2]['d_refid'] . "' value='" . $bestDrinks[2]['CD4'] . "'><label style='color:black;' for='ロック" . $bestDrinks[2]['CD4'] . "'>ロック</label></h4> ";
                              }
                              if ($bestDrinks[2]['CD5'] != 0) {
                                echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='水割り" . $bestDrinks[2]['CD5'] . "'  type='radio' name='b_radio_" . $bestDrinks[2]['d_refid'] . "' value='" . $bestDrinks[2]['CD5'] . "'><label style='color:black;' for='水割り" . $bestDrinks[2]['CD5'] . "'>水割り</label></h4> ";
                              }
                              if ($bestDrinks[2]['CD6'] != 0) {
                                echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='お湯割り" . $bestDrinks[2]['CD6'] . "'  type='radio' name='b_radio_" . $bestDrinks[2]['d_refid'] . "' value='" . $bestDrinks[2]['CD6'] . "'><label style='color:black;' for='お湯割り" . $bestDrinks[2]['CD6'] . "'>お湯割り</label></h4> ";
                              }
                            }
                            if ($bestDrinks[2]['drinktype'] == "ボトル") {
                              $random = rand(10000000, 99999999);
                            ?>
                              <!-----hide counter to add glass----->
                              <div style="display: none;">
                                <h5>
                                  <div class="chooseGlass">お使いのグラスの数を入力してください。</div>
                                </h5>
                                <div class='counter'>
                                  <a onclick="decrement('counter_<?php echo $bestDrinks[2]['d_refid'];
                                                                  echo $random; ?>')" class='counter-button'>-</a>
                                  <input type='text' id='counter_<?php echo $bestDrinks[2]['d_refid'];
                                                                  echo $random; ?>' value='1' class='counter-value' name='glassCount' readonly>
                                  <a onclick="increment('counter_<?php echo $bestDrinks[2]['d_refid'];
                                                                  echo $random; ?>')" class='counter-button'>+</a>
                                </div>
                              </div>
                            <?php
                            }
                            ?>

                            <h5 class="question1"><?php echo $bestDrinks[2]['product'] . 'をカートに追加してよろしいですか' ?></h5>

                          </div>
                        </div>
                      </div>
                      <?php if ($bestDrinks[2]['CD3'] != 0 or $bestDrinks[2]['CD4'] != 0 or $bestDrinks[2]['CD5'] != 0 or $bestDrinks[2]['CD6'] != 0) { ?>
                        <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $bestDrinks[2]['product'] ?>" data-price="<?php echo $bestDrinks[2]['price'] ?>" value="Ok" id="<?php echo $bestDrinks[2]['d_refid']; ?>" onclick="beforeCallCart(<?php echo $bestDrinks[2]['d_refid']; ?>,<?php echo $bestDrinks[2]['CD1']; ?>,<?php echo $random ?>'',true),clearcheckbox()">
                      <?php } else { ?>
                        <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $bestDrinks[2]['product'] ?>" data-price="<?php echo $bestDrinks[2]['price'] ?>" value="Ok" id="<?php echo $bestDrinks[2]['d_refid']; ?>" onclick="callcartoriginal(<?php echo $bestDrinks[2]['d_refid']; ?>,<?php echo $bestDrinks[2]['CD1']; ?>,<?php echo $bestDrinks[2]['CD2']; ?>,<?php echo $random ?>)">
                      <?php } ?>

                    </div>
                  </form>

                  <button type="button" class="roundedbuttonnava" data-dismiss="modal">キャンセル</button>

                </div>

              </div>
            </div>


          <?php
          }
          ?>
        </div>

      <?php } else {

        echo "<div id='menu00' class='tabcontent' >";
        echo "<img style='width: 384px; height:auto;' src='images/cutout/bestof-full.jpeg' alt='' usemap='#m00' > </div>";
      }
      ?>

      <!----------------------------------Menu Items 1--------------------------------->
      <!-- オリジナルボトル -->
      <div id="menu01" class="tabcontent" style="display: none;">
        <img style="width: 384px; height:auto;" src="images/cutout/Menu01.jpeg" alt="" usemap="#m01">

        <?php
        //  print_r($dataarr);exit;
        for ($t = 0; $t < sizeof($dataarr); $t++) {
          if ($dataarr[$t]['menus'] == 1) {

            $staffcom = $dataarr[$t]['drinkinfo'];
            $stockd = $dataarr[$t]['stock_d'];
            if ($stockd <= 0 && $stockd > -100) {
              echo "<div class='containerr'><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01'  title='Out of stock'  class='outofstock' ><div class='centered'> SOLD OUT </div></div>";
            } else {

              if (empty($staffcom)) {
                echo "<img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'>";
              } else {
                echo "<div style='position:relative;'><div data-toggle='modal' data-target='#sm" . $dataarr[$t]['CD2'] . "' id='staffrecom' style='position:absolute;'> <img src='images/cutout/comment.jpeg'> </div><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'></div>";
              }
        ?>
              <!----staff comment info modal------>
              <!-- Modal -->
              <div class="modal fade" id="sm<?php echo $dataarr[$t]['CD2']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <!-- <div class="modal-header"> -->
                    <div class="modal-body">
                      <h5><img src="images/cutout/steward.jpeg" alt=""> <br> <?php echo $dataarr[$t]['drinkinfo']; ?></h5>
                    </div>
                    <!-- </div> -->

                  </div>
                </div>
              </div>

              <!----- check database and import here------>
              <div id="addBookDialog<?php echo $dataarr[$t]['d_refid']; ?>" class="modal fade" role="dialog">
                <div class="modal-dialog modal-dialog-centered" style="width: 350px; margin-left:auto; margin-right:auto;">

                  <!-- Modal content-->
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <!--close button-->
                    <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->

                    <form id="form<?php echo $dataarr[$t]['d_refid']; ?>" action="#" method="GET">
                      <input type="text" hidden value="<?php echo $selectroom; ?>" name="selectroom">
                      <input type="text" hidden value="<?php echo $selectguest; ?>" name="selectguest">
                      <input type="text" hidden value="<?php echo $tableno; ?>" name="tableno">
                      <input type="text" readonly hidden value="<?php echo $dataarr[$t]['product']; ?>" name="prd_name">


                      <div class="modal-body">

                        <div class="form-group">
                          <div class="modal-dialog modal-sm">
                            <div class="modal-content" style="background-color: #e3d3bf;">

                              <input type="text" value="0hgjhgjgjg" id="price<?php echo $dataarr[$t]['d_refid']; ?>" readonly hidden>

                              <?php

                              if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) {
                                echo "<h5 class='question1'>飲み方を選んでください。</h5>";
                                if ($dataarr[$t]['CD3'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ストレート" . $dataarr[$t]['CD3'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD3'] . "'><label style='color:black;' for='ストレート" . $dataarr[$t]['CD3'] . "'>ストレート</label></h4> &nbsp";
                                }
                                if ($dataarr[$t]['CD4'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ロック" . $dataarr[$t]['CD4'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD4'] . "'><label style='color:black;' for='ロック" . $dataarr[$t]['CD4'] . "'>ロック</label></h4> ";
                                }
                                if ($dataarr[$t]['CD5'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='水割り" . $dataarr[$t]['CD5'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD5'] . "'><label style='color:black;' for='水割り" . $dataarr[$t]['CD5'] . "'>水割り</label></h4> ";
                                }
                                if ($dataarr[$t]['CD6'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='お湯割り" . $dataarr[$t]['CD6'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD6'] . "'><label style='color:black;' for='お湯割り" . $dataarr[$t]['CD6'] . "'>お湯割り</label></h4> ";
                                }
                              }
                              if ($dataarr[$t]['drinktype'] == "ボトル") {
                                $random = rand(10000000, 99999999);

                              ?>
                                <!-----hide counter to add glass----->
                                <div style="display: none;">
                                  <h5>
                                    <div class="chooseGlass">お使いのグラスの数を入力してください。</div>
                                  </h5>
                                  <div class='counter'>
                                    <a onclick="decrement('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>-</a>
                                    <input type='text' id='counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>' value='1' class='counter-value' name='glassCount' readonly>
                                    <a onclick="increment('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>+</a>
                                  </div>
                                </div>
                              <?php
                              }
                              ?>

                              <h5 class="question1"><?php echo $dataarr[$t]['product'] . 'をカートに追加してよろしいですか' ?></h5>

                            </div>
                          </div>
                        </div>
                        <?php if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="beforeCallCart(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $random ?>),clearcheckbox()">
                        <?php } else { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="callcartoriginal(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $dataarr[$t]['CD2']; ?>,<?php echo $random ?>)">
                        <?php } ?>

                      </div>
                    </form>

                    <button type="button" class="roundedbuttonnava" data-dismiss="modal">キャンセル</button>

                  </div>

                </div>
              </div>
        <?php
            }
          }
        }
        ?>

        <div>

          <img style="width: 384px; height:auto" src="images/cutout/asset999.jpg" alt="">
        </div>

      </div>

      <!----------------------------------------------------------------------Menu Items 2------------------------------------------------------------>
      <!---- this toggle contain 2 categories in a single button so code is different from a toggle that contain a single category of course------>
      <!--------------- 日本酒　。焼酎 ---------------->


      <!-- 日本酒 --->
      <div id="menu02" class="tabcontent" style="display: none;">


        <img style="width: 384px; height:auto;" src="images/cutout/Menu02.jpeg" alt="" usemap="#m02">


        <?php
        //  print_r($dataarr);exit;
        for ($t = 0; $t < sizeof($dataarr); $t++) {
          if ($dataarr[$t]['menus'] == 2 and $dataarr[$t]['placement'] == 1) {

            $staffcom = $dataarr[$t]['drinkinfo'];
            $stockd = $dataarr[$t]['stock_d'];
            if ($stockd <= 0 && $stockd > -100) {
              echo "<div class='containerr'><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01'  title='Out of stock'  class='outofstock' ><div class='centered'> SOLD OUT </div></div>";
            } else {

              if (empty($staffcom)) {
                echo "<img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'>";
              } else {
                echo "<div style='position:relative;'><div data-toggle='modal' data-target='#sm" . $dataarr[$t]['CD2'] . "' id='staffrecom' style='position:absolute;'> <img src='images/cutout/comment.jpeg'> </div><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'></div>";
              }
        ?>
              <!----staff comment info modal------>
              <!-- Modal -->
              <div class="modal fade" id="sm<?php echo $dataarr[$t]['CD2']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <!-- <div class="modal-header"> -->
                    <div class="modal-body">
                      <h5><img src="images/cutout/steward.jpeg" alt=""> <br> <?php echo $dataarr[$t]['drinkinfo']; ?></h5>
                    </div>
                    <!-- </div> -->

                  </div>
                </div>
              </div>

              <!----- check database and import here------>
              <div id="addBookDialog<?php echo $dataarr[$t]['d_refid']; ?>" class="modal fade" role="dialog">
                <div class="modal-dialog modal-dialog-centered" style="width: 350px; margin-left:auto; margin-right:auto;">

                  <!-- Modal content-->
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <!--close button-->
                    <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->

                    <form id="form<?php echo $dataarr[$t]['d_refid']; ?>" action="#" method="GET">
                      <input type="text" hidden value="<?php echo $selectroom; ?>" name="selectroom">
                      <input type="text" hidden value="<?php echo $selectguest; ?>" name="selectguest">
                      <input type="text" hidden value="<?php echo $tableno; ?>" name="tableno">
                      <input type="text" readonly hidden value="<?php echo $dataarr[$t]['product']; ?>" name="prd_name">


                      <div class="modal-body">

                        <div class="form-group">
                          <div class="modal-dialog modal-sm">
                            <div class="modal-content" style="background-color: #e3d3bf;">

                              <input type="text" value="0hgjhgjgjg" id="price<?php echo $dataarr[$t]['d_refid']; ?>" readonly hidden>

                              <?php
                              if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) {
                                echo "<h5 class='question1'>飲み方を選んでください。</h5>";
                                if ($dataarr[$t]['CD3'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ストレート" . $dataarr[$t]['CD3'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD3'] . "'><label style='color:black;' for='ストレート" . $dataarr[$t]['CD3'] . "'>ストレート</label></h4> &nbsp";
                                }
                                if ($dataarr[$t]['CD4'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ロック" . $dataarr[$t]['CD4'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD4'] . "'><label style='color:black;' for='ロック" . $dataarr[$t]['CD4'] . "'>ロック</label></h4> ";
                                }
                                if ($dataarr[$t]['CD5'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='水割り" . $dataarr[$t]['CD5'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD5'] . "'><label style='color:black;' for='水割り" . $dataarr[$t]['CD5'] . "'>水割り</label></h4> ";
                                }
                                if ($dataarr[$t]['CD6'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='お湯割り" . $dataarr[$t]['CD6'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD6'] . "'><label style='color:black;' for='お湯割り" . $dataarr[$t]['CD6'] . "'>お湯割り</label></h4> ";
                                }
                              }
                              if ($dataarr[$t]['drinktype'] == "ボトル") {
                                $random = rand(10000000, 99999999);

                              ?>
                                <!-----hide counter to add glass----->
                                <div style="display: none;">
                                  <h5>
                                    <div class="chooseGlass">お使いのグラスの数を入力してください。</div>
                                  </h5>
                                  <div class='counter'>
                                    <a onclick="decrement('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>-</a>
                                    <input type='text' id='counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>' value='1' class='counter-value' name='glassCount' readonly>
                                    <a onclick="increment('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>+</a>
                                  </div>
                                </div>
                              <?php
                              }
                              ?>
                              <h5 class="question1"><?php echo $dataarr[$t]['product'] . 'をカートに追加してよろしいですか' ?></h5>

                            </div>
                          </div>
                        </div>
                        <?php if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="beforeCallCart(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $random ?>),clearcheckbox()">
                        <?php } else { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="callcartoriginal(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $dataarr[$t]['CD2']; ?>,<?php echo $random ?>)">
                        <?php } ?>

                      </div>
                    </form>

                    <button type="button" class="roundedbuttonnava" data-dismiss="modal">キャンセル</button>

                  </div>

                </div>
              </div>
        <?php
            }
          }
        }
        ?>


        <!--------------------焼酎----------------------->

        <img style="width: 384px; height:auto;" src="images/cutout/asset88.jpeg" alt="" usemap="#m02">


        <?php
        //  print_r($dataarr);exit;
        for ($t = 0; $t < sizeof($dataarr); $t++) {
          if ($dataarr[$t]['menus'] == 2 and $dataarr[$t]['placement'] == 2) {

            $staffcom = $dataarr[$t]['drinkinfo'];
            $stockd = $dataarr[$t]['stock_d'];
            if ($stockd <= 0 && $stockd > -100) {
              echo "<div class='containerr'><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01'  title='Out of stock'  class='outofstock' ><div class='centered'> SOLD OUT </div></div>";
            } else {

              if (empty($staffcom)) {
                echo "<img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'>";
              } else {
                echo "<div style='position:relative;'><div data-toggle='modal' data-target='#sm" . $dataarr[$t]['CD2'] . "' id='staffrecom' style='position:absolute;'> <img src='images/cutout/comment.jpeg'> </div><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'></div>";
              }
        ?>
              <!----staff comment info modal------>
              <!-- Modal -->
              <div class="modal fade" id="sm<?php echo $dataarr[$t]['CD2']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <!-- <div class="modal-header"> -->
                    <div class="modal-body">
                      <h5><img src="images/cutout/steward.jpeg" alt=""> <br> <?php echo $dataarr[$t]['drinkinfo']; ?></h5>
                    </div>
                    <!-- </div> -->

                  </div>
                </div>
              </div>

              <!----- check database and import here------>

              <div id="addBookDialog<?php echo $dataarr[$t]['d_refid']; ?>" class="modal fade" role="dialog">
                <div class="modal-dialog modal-dialog-centered" style="width: 350px; margin-left:auto; margin-right:auto;">

                  <!-- Modal content-->
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <!--close button-->
                    <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->

                    <form id="form<?php echo $dataarr[$t]['d_refid']; ?>" action="#" method="GET">
                      <input type="text" hidden value="<?php echo $selectroom; ?>" name="selectroom">
                      <input type="text" hidden value="<?php echo $selectguest; ?>" name="selectguest">
                      <input type="text" hidden value="<?php echo $tableno; ?>" name="tableno">
                      <input type="text" readonly hidden value="<?php echo $dataarr[$t]['product']; ?>" name="prd_name">


                      <div class="modal-body">

                        <div class="form-group">
                          <div class="modal-dialog modal-sm">
                            <div class="modal-content" style="background-color: #e3d3bf;">

                              <input type="text" value="0hgjhgjgjg" id="price<?php echo $dataarr[$t]['d_refid']; ?>" readonly hidden>

                              <?php

                              if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) {
                                echo "<h5 class='question1'>飲み方を選んでください。</h5>";
                                if ($dataarr[$t]['CD3'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ストレート" . $dataarr[$t]['CD3'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD3'] . "'><label style='color:black;' for='ストレート" . $dataarr[$t]['CD3'] . "'>ストレート</label></h4> &nbsp";
                                }
                                if ($dataarr[$t]['CD4'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ロック" . $dataarr[$t]['CD4'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD4'] . "'><label style='color:black;' for='ロック" . $dataarr[$t]['CD4'] . "'>ロック</label></h4> ";
                                }
                                if ($dataarr[$t]['CD5'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='水割り" . $dataarr[$t]['CD5'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD5'] . "'><label style='color:black;' for='水割り" . $dataarr[$t]['CD5'] . "'>水割り</label></h4> ";
                                }
                                if ($dataarr[$t]['CD6'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='お湯割り" . $dataarr[$t]['CD6'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD6'] . "'><label style='color:black;' for='お湯割り" . $dataarr[$t]['CD6'] . "'>お湯割り</label></h4> ";
                                }
                              }
                              if ($dataarr[$t]['drinktype'] == "ボトル") {
                                $random = rand(10000000, 99999999);

                              ?>
                                <!-----hide counter to add glass----->
                                <div style="display: none;">
                                  <h5>
                                    <div class="chooseGlass">お使いのグラスの数を入力してください。</div>
                                  </h5>
                                  <div class='counter'>
                                    <a onclick="decrement('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>-</a>
                                    <input type='text' id='counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>' value='1' class='counter-value' name='glassCount' readonly>
                                    <a onclick="increment('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>+</a>
                                  </div>
                                </div>
                              <?php
                              }
                              ?>

                              <h5 class="question1"><?php echo $dataarr[$t]['product'] . 'をカートに追加してよろしいですか' ?></h5>

                            </div>
                          </div>
                        </div>
                        <?php if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="beforeCallCart(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $random ?>),clearcheckbox()">
                        <?php } else { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="callcartoriginal(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $dataarr[$t]['CD2']; ?>,<?php echo $random ?>)">
                        <?php } ?>

                      </div>
                    </form>

                    <button type="button" class="roundedbuttonnava" data-dismiss="modal">キャンセル</button>

                  </div>

                </div>
              </div>
        <?php
            }
          }
        }
        ?>


        <div>
          <img style="width: 384px; height:auto" src="images/cutout/syochu.png" alt="">
        </div>


      </div>

      <!-------------------------------------------------------------------------Menu Items 3-------------------------------------------------------------->
      <!---- this toggle contain 2 categories in a single button so code is different from a toggle that contain a single category of course------>
      <!--ビール　。ウイスキー　-->
      <!----ウイスキー---->
      <div id="menu03" class="tabcontent" style="display: none;">
        <img style="width: 384px; height:auto" src="images/cutout/Menu03.jpeg" alt="" usemap="#m03">


        <?php
        //  print_r($dataarr);exit;
        for ($t = 0; $t < sizeof($dataarr); $t++) {
          if ($dataarr[$t]['menus'] == 3 and $dataarr[$t]['placement'] == 1) {

            $staffcom = $dataarr[$t]['drinkinfo'];
            $stockd = $dataarr[$t]['stock_d'];
            if ($stockd <= 0 && $stockd > -100) {
              echo "<div class='containerr'><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01'  title='Out of stock'  class='outofstock' ><div class='centered'> SOLD OUT </div></div>";
            } else {

              if (empty($staffcom)) {
                echo "<img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'>";
              } else {
                echo "<div style='position:relative;'><div data-toggle='modal' data-target='#sm" . $dataarr[$t]['CD2'] . "' id='staffrecom' style='position:absolute;'> <img src='images/cutout/comment.jpeg'> </div><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'></div>";
              }
        ?>
              <!----staff comment info modal------>
              <!-- Modal -->
              <div class="modal fade" id="sm<?php echo $dataarr[$t]['CD2']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <!-- <div class="modal-header"> -->
                    <div class="modal-body">
                      <h5><img src="images/cutout/steward.jpeg" alt=""> <br> <?php echo $dataarr[$t]['drinkinfo']; ?></h5>
                    </div>
                    <!-- </div> -->

                  </div>
                </div>
              </div>

              <!----- check database and import here------>
              <div id="addBookDialog<?php echo $dataarr[$t]['d_refid']; ?>" class="modal fade" role="dialog">
                <div class="modal-dialog modal-dialog-centered" style="width: 350px; margin-left:auto; margin-right:auto;">

                  <!-- Modal content-->
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <!--close button-->
                    <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->

                    <form id="form<?php echo $dataarr[$t]['d_refid']; ?>" action="#" method="GET">
                      <input type="text" hidden value="<?php echo $selectroom; ?>" name="selectroom">
                      <input type="text" hidden value="<?php echo $selectguest; ?>" name="selectguest">
                      <input type="text" hidden value="<?php echo $tableno; ?>" name="tableno">
                      <input type="text" readonly hidden value="<?php echo $dataarr[$t]['product']; ?>" name="prd_name">


                      <div class="modal-body">

                        <div class="form-group">
                          <div class="modal-dialog modal-sm">
                            <div class="modal-content" style="background-color: #e3d3bf;">

                              <input type="text" value="0hgjhgjgjg" id="price<?php echo $dataarr[$t]['d_refid']; ?>" readonly hidden>

                              <?php

                              if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) {
                                echo "<h5 class='question1'>飲み方を選んでください。</h5>";
                                if ($dataarr[$t]['CD3'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ストレート" . $dataarr[$t]['CD3'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD3'] . "'><label style='color:black;' for='ストレート" . $dataarr[$t]['CD3'] . "'>ストレート</label></h4> &nbsp";
                                }
                                if ($dataarr[$t]['CD4'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ロック" . $dataarr[$t]['CD4'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD4'] . "'><label style='color:black;' for='ロック" . $dataarr[$t]['CD4'] . "'>ロック</label></h4> ";
                                }
                                if ($dataarr[$t]['CD5'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='水割り" . $dataarr[$t]['CD5'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD5'] . "'><label style='color:black;' for='水割り" . $dataarr[$t]['CD5'] . "'>水割り</label></h4> ";
                                }
                                if ($dataarr[$t]['CD6'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='お湯割り" . $dataarr[$t]['CD6'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD6'] . "'><label style='color:black;' for='お湯割り" . $dataarr[$t]['CD6'] . "'>お湯割り</label></h4> ";
                                }
                              }
                              if ($dataarr[$t]['drinktype'] == "ボトル") {
                                $random = rand(10000000, 99999999);

                              ?>
                                <!-----hide counter to add glass----->
                                <div style="display: none;">
                                  <h5>
                                    <div class="chooseGlass">お使いのグラスの数を入力してください。</div>
                                  </h5>
                                  <div class='counter'>
                                    <a onclick="decrement('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>-</a>
                                    <input type='text' id='counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>' value='1' class='counter-value' name='glassCount' readonly>
                                    <a onclick="increment('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>+</a>
                                  </div>
                                </div>
                              <?php
                              }
                              ?>

                              <h5 class="question1"><?php echo $dataarr[$t]['product'] . 'をカートに追加してよろしいですか' ?></h5>

                            </div>
                          </div>
                        </div>
                        <?php if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="beforeCallCart(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $random ?>),clearcheckbox()">
                        <?php } else { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="callcartoriginal(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $dataarr[$t]['CD2']; ?>,<?php echo $random ?>)">
                        <?php } ?>

                      </div>
                    </form>

                    <button type="button" class="roundedbuttonnava" data-dismiss="modal">キャンセル</button>

                  </div>

                </div>
              </div>
        <?php
            }
          }
        }
        ?>

        <!-----------------ウイスキー------------------->

        <img style="width: 384px; height:auto;" src="images/cutout/asset84.jpeg" alt="" usemap="#m02">
        <?php
        //  print_r($dataarr);exit;
        for ($t = 0; $t < sizeof($dataarr); $t++) {
          if ($dataarr[$t]['menus'] == 3 and $dataarr[$t]['placement'] == 2) {

            $staffcom = $dataarr[$t]['drinkinfo'];

            $stockd = $dataarr[$t]['stock_d'];
            if ($stockd <= 0 && $stockd > -100) {
              echo "<div class='containerr'><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01'  title='Out of stock'  class='outofstock' ><div class='centered'> SOLD OUT </div></div>";
            } else {

              if (empty($staffcom)) {
                echo "<img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'>";
              } else {
                echo "<div style='position:relative;'><div data-toggle='modal' data-target='#sm" . $dataarr[$t]['CD2'] . "' id='staffrecom' style='position:absolute;'> <img src='images/cutout/comment.jpeg'> </div><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'></div>";
              }
        ?>
              <!----staff comment info modal------>
              <!-- Modal -->
              <div class="modal fade" id="sm<?php echo $dataarr[$t]['CD2']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <!-- <div class="modal-header"> -->
                    <div class="modal-body">
                      <h5><img src="images/cutout/steward.jpeg" alt=""> <br> <?php echo $dataarr[$t]['drinkinfo']; ?></h5>
                    </div>
                    <!-- </div> -->

                  </div>
                </div>
              </div>

              <!----- check database and import here------>
              <div id="addBookDialog<?php echo $dataarr[$t]['d_refid']; ?>" class="modal fade" role="dialog">
                <div class="modal-dialog modal-dialog-centered" style="width: 350px; margin-left:auto; margin-right:auto;">

                  <!-- Modal content-->
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <!--close button-->
                    <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->

                    <form id="form<?php echo $dataarr[$t]['d_refid']; ?>" action="#" method="GET">
                      <input type="text" hidden value="<?php echo $selectroom; ?>" name="selectroom">
                      <input type="text" hidden value="<?php echo $selectguest; ?>" name="selectguest">
                      <input type="text" hidden value="<?php echo $tableno; ?>" name="tableno">
                      <input type="text" readonly hidden value="<?php echo $dataarr[$t]['product']; ?>" name="prd_name">


                      <div class="modal-body">

                        <div class="form-group">
                          <div class="modal-dialog modal-sm">
                            <div class="modal-content" style="background-color: #e3d3bf;">

                              <input type="text" value="0hgjhgjgjg" id="price<?php echo $dataarr[$t]['d_refid']; ?>" readonly hidden>

                              <?php

                              if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) {
                                echo "<h5 class='question1'>飲み方を選んでください。</h5>";
                                if ($dataarr[$t]['CD3'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ストレート" . $dataarr[$t]['CD3'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD3'] . "'><label style='color:black;' for='ストレート" . $dataarr[$t]['CD3'] . "'>ストレート</label></h4> &nbsp";
                                }
                                if ($dataarr[$t]['CD4'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ロック" . $dataarr[$t]['CD4'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD4'] . "'><label style='color:black;' for='ロック" . $dataarr[$t]['CD4'] . "'>ロック</label></h4> ";
                                }
                                if ($dataarr[$t]['CD5'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='水割り" . $dataarr[$t]['CD5'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD5'] . "'><label style='color:black;' for='水割り" . $dataarr[$t]['CD5'] . "'>水割り</label></h4> ";
                                }
                                if ($dataarr[$t]['CD6'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='お湯割り" . $dataarr[$t]['CD6'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD6'] . "'><label style='color:black;' for='お湯割り" . $dataarr[$t]['CD6'] . "'>お湯割り</label></h4> ";
                                }
                              }
                              if ($dataarr[$t]['drinktype'] == "ボトル") {
                                $random = rand(10000000, 99999999);

                              ?>
                                <!-----hide counter to add glass----->
                                <div style="display: none;">
                                  <h5>
                                    <div class="chooseGlass">お使いのグラスの数を入力してください。</div>
                                  </h5>
                                  <div class='counter'>
                                    <a onclick="decrement('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>-</a>
                                    <input type='text' id='counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>' value='1' class='counter-value' name='glassCount' readonly>
                                    <a onclick="increment('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>+</a>
                                  </div>
                                </div>
                              <?php
                              }
                              ?>
                              <h5 class="question1"><?php echo $dataarr[$t]['product'] . 'をカートに追加してよろしいですか' ?></h5>

                            </div>
                          </div>
                        </div>
                        <?php if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="beforeCallCart(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $random ?>),clearcheckbox()">
                        <?php } else { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="callcartoriginal(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $dataarr[$t]['CD2']; ?>,<?php echo $random ?>)">
                        <?php } ?>

                      </div>
                    </form>

                    <button type="button" class="roundedbuttonnava" data-dismiss="modal">キャンセル</button>

                  </div>

                </div>
              </div>
        <?php
            }
          }
        }
        ?>

      </div>


      <!--------------------------------------------------------------------Menu Items 4---------------------------------------------------------------->
      <!---- this toggle contain 2 categories in a single button so code is different from a toggle that contain a single category of course------>
      <!-- サワー　。　果実酒　-->
      <!-- サワー-->
      <div id="menu04" class="tabcontent" style="display: none;">
        <img style="width: 384px; height:auto" src="images/cutout/Menu04.jpeg" alt="" usemap="#m04">


        <?php
        //  print_r($dataarr);exit;
        for ($t = 0; $t < sizeof($dataarr); $t++) {
          if ($dataarr[$t]['menus'] == 4 and $dataarr[$t]['placement'] == 1) {

            $staffcom = $dataarr[$t]['drinkinfo'];

            $stockd = $dataarr[$t]['stock_d'];
            if ($stockd <= 0 && $stockd > -100) {
              echo "<div class='containerr'><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01'  title='Out of stock'  class='outofstock' ><div class='centered'> SOLD OUT </div></div>";
            } else {

              if (empty($staffcom)) {
                echo "<img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'>";
              } else {
                echo "<div style='position:relative;'><div data-toggle='modal' data-target='#sm" . $dataarr[$t]['CD2'] . "' id='staffrecom' style='position:absolute;'> <img src='images/cutout/comment.jpeg'> </div><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'></div>";
              }
        ?>
              <!----staff comment info modal------>
              <!-- Modal -->
              <div class="modal fade" id="sm<?php echo $dataarr[$t]['CD2']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <!-- <div class="modal-header"> -->
                    <div class="modal-body">
                      <h5><img src="images/cutout/steward.jpeg" alt=""> <br> <?php echo $dataarr[$t]['drinkinfo']; ?></h5>
                    </div>
                    <!-- </div> -->

                  </div>
                </div>
              </div>

              <!----- check database and import here------>
              <div id="addBookDialog<?php echo $dataarr[$t]['d_refid']; ?>" class="modal fade" role="dialog">
                <div class="modal-dialog modal-dialog-centered" style="width: 350px; margin-left:auto; margin-right:auto;">

                  <!-- Modal content-->
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <!--close button-->
                    <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->

                    <form id="form<?php echo $dataarr[$t]['d_refid']; ?>" action="#" method="GET">
                      <input type="text" hidden value="<?php echo $selectroom; ?>" name="selectroom">
                      <input type="text" hidden value="<?php echo $selectguest; ?>" name="selectguest">
                      <input type="text" hidden value="<?php echo $tableno; ?>" name="tableno">
                      <input type="text" readonly hidden value="<?php echo $dataarr[$t]['product']; ?>" name="prd_name">


                      <div class="modal-body">

                        <div class="form-group">
                          <div class="modal-dialog modal-sm">
                            <div class="modal-content" style="background-color: #e3d3bf;">

                              <input type="text" value="0hgjhgjgjg" id="price<?php echo $dataarr[$t]['d_refid']; ?>" readonly hidden>

                              <?php

                              if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) {
                                echo "<h5 class='question1'>飲み方を選んでください。</h5>";
                                if ($dataarr[$t]['CD3'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ストレート" . $dataarr[$t]['CD3'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD3'] . "'><label style='color:black;' for='ストレート" . $dataarr[$t]['CD3'] . "'>ストレート</label></h4> &nbsp";
                                }
                                if ($dataarr[$t]['CD4'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ロック" . $dataarr[$t]['CD4'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD4'] . "'><label style='color:black;' for='ロック" . $dataarr[$t]['CD4'] . "'>ロック</label></h4> ";
                                }
                                if ($dataarr[$t]['CD5'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='水割り" . $dataarr[$t]['CD5'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD5'] . "'><label style='color:black;' for='水割り" . $dataarr[$t]['CD5'] . "'>水割り</label></h4> ";
                                }
                                if ($dataarr[$t]['CD6'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='お湯割り" . $dataarr[$t]['CD6'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD6'] . "'><label style='color:black;' for='お湯割り" . $dataarr[$t]['CD6'] . "'>お湯割り</label></h4> ";
                                }
                              }
                              if ($dataarr[$t]['drinktype'] == "ボトル") {
                                $random = rand(10000000, 99999999);

                              ?>
                                <!-----hide counter to add glass----->
                                <div style="display: none;">
                                  <h5>
                                    <div class="chooseGlass">お使いのグラスの数を入力してください。</div>
                                  </h5>
                                  <div class='counter'>
                                    <a onclick="decrement('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>-</a>
                                    <input type='text' id='counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>' value='1' class='counter-value' name='glassCount' readonly>
                                    <a onclick="increment('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>+</a>
                                  </div>
                                </div>
                              <?php
                              }
                              ?>

                              <h5 class="question1"><?php echo $dataarr[$t]['product'] . 'をカートに追加してよろしいですか' ?></h5>

                            </div>
                          </div>
                        </div>
                        <?php if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="beforeCallCart(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $random ?>),clearcheckbox()">
                        <?php } else { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="callcartoriginal(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $dataarr[$t]['CD2']; ?>,<?php echo $random ?>)">
                        <?php } ?>

                      </div>
                    </form>

                    <button type="button" class="roundedbuttonnava" data-dismiss="modal">キャンセル</button>

                  </div>

                </div>
              </div>
        <?php
            }
          }
        }
        ?>


        <!--------------果実酒---------------->

        <img style="width: 384px; height:auto;" src="images/cutout/asset89.jpeg" alt="" usemap="#m02">


        <?php
        //  print_r($dataarr);exit;
        for ($t = 0; $t < sizeof($dataarr); $t++) {
          if ($dataarr[$t]['menus'] == 4 and $dataarr[$t]['placement'] == 2) {

            $staffcom = $dataarr[$t]['drinkinfo'];

            $stockd = $dataarr[$t]['stock_d'];
            if ($stockd <= 0 && $stockd > -100) {
              echo "<div class='containerr'><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01'  title='Out of stock'  class='outofstock' ><div class='centered'> SOLD OUT </div></div>";
            } else {

              if (empty($staffcom)) {
                echo "<img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'>";
              } else {
                echo "<div style='position:relative;'><div data-toggle='modal' data-target='#sm" . $dataarr[$t]['CD2'] . "' id='staffrecom' style='position:absolute;'> <img src='images/cutout/comment.jpeg'> </div><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'></div>";
              }
        ?>
              <!----staff comment info modal------>
              <!-- Modal -->
              <div class="modal fade" id="sm<?php echo $dataarr[$t]['CD2']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <!-- <div class="modal-header"> -->
                    <div class="modal-body">
                      <h5><img src="images/cutout/steward.jpeg" alt=""> <br> <?php echo $dataarr[$t]['drinkinfo']; ?></h5>
                    </div>
                    <!-- </div> -->

                  </div>
                </div>
              </div>

              <!----- check database and import here------>
              <div id="addBookDialog<?php echo $dataarr[$t]['d_refid']; ?>" class="modal fade" role="dialog">
                <div class="modal-dialog modal-dialog-centered" style="width: 350px; margin-left:auto; margin-right:auto;">

                  <!-- Modal content-->
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <!--close button-->
                    <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->

                    <form id="form<?php echo $dataarr[$t]['d_refid']; ?>" action="#" method="GET">
                      <input type="text" hidden value="<?php echo $selectroom; ?>" name="selectroom">
                      <input type="text" hidden value="<?php echo $selectguest; ?>" name="selectguest">
                      <input type="text" hidden value="<?php echo $tableno; ?>" name="tableno">
                      <input type="text" readonly hidden value="<?php echo $dataarr[$t]['product']; ?>" name="prd_name">


                      <div class="modal-body">

                        <div class="form-group">
                          <div class="modal-dialog modal-sm">
                            <div class="modal-content" style="background-color: #e3d3bf;">

                              <input type="text" value="0hgjhgjgjg" id="price<?php echo $dataarr[$t]['d_refid']; ?>" readonly hidden>

                              <?php

                              if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) {
                                echo "<h5 class='question1'>飲み方を選んでください。</h5>";
                                if ($dataarr[$t]['CD3'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ストレート" . $dataarr[$t]['CD3'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD3'] . "'><label style='color:black;' for='ストレート" . $dataarr[$t]['CD3'] . "'>ストレート</label></h4> &nbsp";
                                }
                                if ($dataarr[$t]['CD4'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ロック" . $dataarr[$t]['CD4'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD4'] . "'><label style='color:black;' for='ロック" . $dataarr[$t]['CD4'] . "'>ロック</label></h4> ";
                                }
                                if ($dataarr[$t]['CD5'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='水割り" . $dataarr[$t]['CD5'] . "'  type='radio' CHECKED name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD5'] . "'><label style='color:black;' for='水割り" . $dataarr[$t]['CD5'] . "'>水割り</label></h4> ";
                                }
                                if ($dataarr[$t]['CD6'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='お湯割り" . $dataarr[$t]['CD6'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD6'] . "'><label style='color:black;' for='お湯割り" . $dataarr[$t]['CD6'] . "'>お湯割り</label></h4> ";
                                }
                              }
                              if ($dataarr[$t]['drinktype'] == "ボトル") {
                                $random = rand(10000000, 99999999);

                              ?>

                                <!-----hide counter to add glass----->
                                <div style="display: none;">
                                  <h5>
                                    <div class="chooseGlass">お使いのグラスの数を入力してください。</div>
                                  </h5>
                                  <div class='counter'>
                                    <a onclick="decrement('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>-</a>
                                    <input type='text' id='counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>' value='1' class='counter-value' name='glassCount' readonly>
                                    <a onclick="increment('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>+</a>
                                  </div>
                                     
                                </div>
                              <?php
                              }
                              ?>

                              <h5 class="question1"><?php echo $dataarr[$t]['product'] . 'をカートに追加してよろしいですか' ?></h5>

                            </div>
                          </div>
                        </div>
                        <?php if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="beforeCallCart(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $random ?>),clearcheckbox()">
                        <?php } else { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="callcartoriginal(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $dataarr[$t]['CD2']; ?>,<?php echo $random ?>)">
                        <?php } ?>

                      </div>
                    </form>
                    <button type="button" class="roundedbuttonnava" data-dismiss="modal">キャンセル</button>
                  </div>

                </div>
              </div>
        <?php
            }
          }
        }
        ?>

      </div>



      <!----------------------------------------------------------------------------Menu Items 5---------------------------------------------------------->
      <!--ワイン-->
      <div id="menu05" class="tabcontent" style="display: none;">
        <img style="width: 384px; height:auto" src="images/cutout/Menu05.jpeg" alt="" usemap="#m05">


        <?php
        //  print_r($dataarr);exit;
        for ($t = 0; $t < sizeof($dataarr); $t++) {
          if ($dataarr[$t]['menus'] == 5) {

            $staffcom = $dataarr[$t]['drinkinfo'];

            $stockd = $dataarr[$t]['stock_d'];
            if ($stockd <= 0 && $stockd > -100) {
              echo "<div class='containerr'><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01'  title='Out of stock'  class='outofstock' ><div class='centered'> SOLD OUT </div></div>";
            } else {

              if (empty($staffcom)) {
                echo "<img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'>";
              } else {
                echo "<div style='position:relative;'><div data-toggle='modal' data-target='#sm" . $dataarr[$t]['CD2'] . "' id='staffrecom' style='position:absolute;'> <img src='images/cutout/comment.jpeg'> </div><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'></div>";
              }
        ?>
              <!----staff comment info modal------>
              <!-- Modal -->
              <div class="modal fade" id="sm<?php echo $dataarr[$t]['CD2']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <!-- <div class="modal-header"> -->
                    <div class="modal-body">
                      <h5><img src="images/cutout/steward.jpeg" alt=""> <br> <?php echo $dataarr[$t]['drinkinfo']; ?></h5>
                    </div>
                    <!-- </div> -->

                  </div>
                </div>
              </div>

              <!----- check database and import here------>
              <div id="addBookDialog<?php echo $dataarr[$t]['d_refid']; ?>" class="modal fade" role="dialog">
                <div class="modal-dialog modal-dialog-centered" style="width: 350px; margin-left:auto; margin-right:auto;">

                  <!-- Modal content-->
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <!--close button-->
                    <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->

                    <form id="form<?php echo $dataarr[$t]['d_refid']; ?>" action="#" method="GET">
                      <input type="text" hidden value="<?php echo $selectroom; ?>" name="selectroom">
                      <input type="text" hidden value="<?php echo $selectguest; ?>" name="selectguest">
                      <input type="text" hidden value="<?php echo $tableno; ?>" name="tableno">
                      <input type="text" readonly hidden value="<?php echo $dataarr[$t]['product']; ?>" name="prd_name">


                      <div class="modal-body">

                        <div class="form-group">
                          <div class="modal-dialog modal-sm">
                            <div class="modal-content" style="background-color: #e3d3bf;">

                              <input type="text" value="0hgjhgjgjg" id="price<?php echo $dataarr[$t]['d_refid']; ?>" readonly hidden>

                              <?php

                              if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) {
                                echo "<h5 class='question1'>飲み方を選んでください。</h5>";
                                if ($dataarr[$t]['CD3'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ストレート" . $dataarr[$t]['CD3'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD3'] . "'><label style='color:black;' for='ストレート" . $dataarr[$t]['CD3'] . "'>ストレート</label></h4> &nbsp";
                                }
                                if ($dataarr[$t]['CD4'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ロック" . $dataarr[$t]['CD4'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD4'] . "'><label style='color:black;' for='ロック" . $dataarr[$t]['CD4'] . "'>ロック</label></h4> ";
                                }
                                if ($dataarr[$t]['CD5'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='水割り" . $dataarr[$t]['CD5'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD5'] . "'><label style='color:black;' for='水割り" . $dataarr[$t]['CD5'] . "'>水割り</label></h4> ";
                                }
                                if ($dataarr[$t]['CD6'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='お湯割り" . $dataarr[$t]['CD6'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD6'] . "'><label style='color:black;' for='お湯割り" . $dataarr[$t]['CD6'] . "'>お湯割り</label></h4> ";
                                }
                              }
                              if ($dataarr[$t]['drinktype'] == "ボトル") {
                                $random = rand(10000000, 99999999);

                              ?>
                                <!-----hide counter to add glass----->
                                <div style="display: none;">
                                  <h5>
                                    <div class="chooseGlass">お使いのグラスの数を入力してください。</div>
                                  </h5>
                                      <div class='counter'>
                                        <a onclick="decrement('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                        echo $random; ?>')" class='counter-button'>-</a>
                                        <input type='text' id='counter_<?php echo $dataarr[$t]['d_refid'];
                                                                        echo $random; ?>' value='1' class='counter-value' name='glassCount' readonly>
                                        <a onclick="increment('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                        echo $random; ?>')" class='counter-button'>+</a>
                                      </div>
                                </div>
                              <?php
                              }
                              ?>

                              <h5 class="question1"><?php echo $dataarr[$t]['product'] . 'をカートに追加してよろしいですか' ?></h5>

                            </div>
                          </div>
                        </div>
                        <?php if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) { ?>
                          <input type="button" class="roundedbuttonextra" data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="beforeCallCart(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $random ?>),clearcheckbox()">
                        <?php } else { ?>
                          <input type="button" class="roundedbuttonextra" data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="callcartoriginal(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $dataarr[$t]['CD2']; ?>,<?php echo $random ?>)">
                        <?php } ?>

                      </div>
                    </form>

                    <button type="button" class="roundedbuttonnava" data-dismiss="modal">キャンセル</button>

                  </div>

                </div>
              </div>
        <?php
            }
          }
        }
        ?>

        <img style="width: 384px; height:auto" src="images/cutout/asset131.jpeg" alt="">

      </div>



      <!----------------------------------------------------------------------Menu Items 6-------------------------------------------------------------->
      <!--ソフトドリンク-->
      <div id="menu06" class="tabcontent" style="display: none;">
        <img style="width: 384px; height:auto" src="images/cutout/Menu06.jpeg" alt="" usemap="#m06">


        <?php
        //  print_r($dataarr);exit;
        for ($t = 0; $t < sizeof($dataarr); $t++) {
          if ($dataarr[$t]['menus'] == 6) {

            $staffcom = $dataarr[$t]['drinkinfo'];

            $stockd = $dataarr[$t]['stock_d'];
            if ($stockd <= 0 && $stockd > -100) {
              echo "<div class='containerr'><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01'  title='Out of stock'  class='outofstock' ><div class='centered'> SOLD OUT </div></div>";
            } else {

              if (empty($staffcom)) {
                echo "<img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'>";
              } else {
                echo "<div style='position:relative;'><div data-toggle='modal' data-target='#sm" . $dataarr[$t]['CD2'] . "' id='staffrecom' style='position:absolute;'> <img src='images/cutout/comment.jpeg'> </div><img style='width: 384px; height:auto;' src='upload/" . $dataarr[$t]['productimage'] . "' usemap='#m01" . $stk . "' data-toggle='modal' data-id='ISBN-001122'   href='#addBookDialog" . $dataarr[$t]['d_refid'] . "' onclick='calval(" . $dataarr[$t]['d_refid'] . ")'></div>";
              }
        ?>
              <!----staff comment info modal------>
              <!-- Modal -->
              <div class="modal fade" id="sm<?php echo $dataarr[$t]['CD2']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <!-- <div class="modal-header"> -->
                    <div class="modal-body">
                      <h5><img src="images/cutout/steward.jpeg" alt=""> <br> <?php echo $dataarr[$t]['drinkinfo']; ?></h5>
                    </div>
                    <!-- </div> -->

                  </div>
                </div>
              </div>

              <!----- check database and import here------>
              <div id="addBookDialog<?php echo $dataarr[$t]['d_refid']; ?>" class="modal fade" role="dialog">
                <div class="modal-dialog modal-dialog-centered" style="width: 350px; margin-left:auto; margin-right:auto;">

                  <!-- Modal content-->
                  <div class="modal-content" style="background-color: #e3d3bf;border-radius:40px">

                    <!--close button-->
                    <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->

                    <form id="form<?php echo $dataarr[$t]['d_refid']; ?>" action="#" method="GET">
                      <input type="text" hidden value="<?php echo $selectroom; ?>" name="selectroom">
                      <input type="text" hidden value="<?php echo $selectguest; ?>" name="selectguest">
                      <input type="text" hidden value="<?php echo $tableno; ?>" name="tableno">
                      <input type="text" readonly hidden value="<?php echo $dataarr[$t]['product']; ?>" name="prd_name">


                      <div class="modal-body">

                        <div class="form-group">
                          <div class="modal-dialog modal-sm">
                            <div class="modal-content" style="background-color: #e3d3bf;">

                              <input type="text" value="0hgjhgjgjg" id="price<?php echo $dataarr[$t]['d_refid']; ?>" readonly hidden>

                              <?php

                              if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) {
                                echo "<h5 class='question1'>飲み方を選んでください。</h5>";
                                if ($dataarr[$t]['CD3'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ストレート" . $dataarr[$t]['CD3'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD3'] . "'><label style='color:black;' for='ストレート" . $dataarr[$t]['CD3'] . "'>ストレート</label></h4> &nbsp";
                                }
                                if ($dataarr[$t]['CD4'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='ロック" . $dataarr[$t]['CD4'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD4'] . "'><label style='color:black;' for='ロック" . $dataarr[$t]['CD4'] . "'>ロック</label></h4> ";
                                }
                                if ($dataarr[$t]['CD5'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='水割り" . $dataarr[$t]['CD5'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD5'] . "'><label style='color:black;' for='水割り" . $dataarr[$t]['CD5'] . "'>水割り</label></h4> ";
                                }
                                if ($dataarr[$t]['CD6'] != 0) {
                                  echo "<h4 class='mr-auto' style='margin-left:30px;'><input id='お湯割り" . $dataarr[$t]['CD6'] . "'  type='radio' name='radio_" . $dataarr[$t]['d_refid'] . "' value='" . $dataarr[$t]['CD6'] . "'><label style='color:black;' for='お湯割り" . $dataarr[$t]['CD6'] . "'>お湯割り</label></h4> ";
                                }
                              }
                              if ($dataarr[$t]['drinktype'] == "ボトル") {
                                $random = rand(10000000, 99999999);
                              ?>
                                <!-----hide counter to add glass----->
                                <div style="display: none;">
                                  <h5>
                                    <div class="chooseGlass">お使いのグラスの数を入力してください。</div>
                                  </h5>
                                  <div class='counter'>
                                    <a onclick="decrement('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>-</a>
                                    <input type='text' id='counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>' value='1' class='counter-value' name='glassCount' readonly>
                                    <a onclick="increment('counter_<?php echo $dataarr[$t]['d_refid'];
                                                                    echo $random; ?>')" class='counter-button'>+</a>
                                  </div>
                                </div>
                              <?php
                              }
                              ?>

                              <h5 class="question1"><?php echo $dataarr[$t]['product'] . 'をカートに追加してよろしいですか' ?></h5>

                            </div>
                          </div>
                        </div>
                        <?php if ($dataarr[$t]['CD3'] != 0 or $dataarr[$t]['CD4'] != 0 or $dataarr[$t]['CD5'] != 0 or $dataarr[$t]['CD6'] != 0) { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="beforeCallCart(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $random ?>),clearcheckbox()">
                        <?php } else { ?>
                          <input type="button" class="roundedbuttonextra " data-dismiss="modal" data-name="<?php echo $dataarr[$t]['product'] ?>" data-price="<?php echo $dataarr[$t]['price'] ?>" value="Ok" id="<?php echo $dataarr[$t]['d_refid']; ?>" onclick="callcartoriginal(<?php echo $dataarr[$t]['d_refid']; ?>,<?php echo $dataarr[$t]['CD1']; ?>,<?php echo $dataarr[$t]['CD2']; ?>,<?php echo $random ?>)">
                        <?php } ?>

                      </div>
                    </form>

                    <button type="button" class="roundedbuttonnava" data-dismiss="modal">キャンセル</button>

                  </div>

                </div>
              </div>
        <?php
            }
          }
        }
        ?>

      </div>



      <!----------------------------------Menu Items end--------------------------------->

      <div class="footer">
        <hr class="solid">
        <span style="color: #595143; font-size:8px"> ® <script type="text/javascript">
            document.write(new Date().getFullYear());
          </script> Yunokawa Prince Hotel Nagisatei • All Rights Reserved</span>
      </div>

      <!----------------------------------footer end--------------------------------->


    </div>
    <script src="js/main.js"></script>
    <script>
      /**************************************************/

      function calval(pass) {
        var price = $('#prc' + pass).val();
        var qty = $('#qty' + pass).val();
        //alert(qty);
        var tot = price * qty;
        document.getElementById('price' + pass).value = tot; //returns a HTML DOM Object
        //alert(price);
      }

      /**************************************************/

      function callcart(id, cd1, cd2, newName) {
        event.preventDefault();
        var name = $("#" + id).data('name');
        if (typeof newName !== 'undefined') {
          name = name + " " + newName;
        }

      }

      /**************************************************/

      function beforeCallCart(id, cd1, random, isBestOf = false) {
        event.preventDefault();

        console.log(random);
        var name = $("#" + id).data('name');
        var price = ($("#" + id).data('price'));
        if (isBestOf) {
          var radiostyle = $('input[name=b_radio_' + id + ']:checked').val();
        } else {
          var radiostyle = $('input[name=radio_' + id + ']:checked').val();
        }
        if (typeof random !== 'undefined') {
          var _id = '#counter_' + id + random;
        } else {
          var _id = '#counter_' + id;
        }
        console.log(_id);
        if (isBestOf) {
          var flavor = $('input[name=b_radio_' + id + ']:checked').parent().text();
        } else {
          var flavor = $('input[name=radio_' + id + ']:checked').parent().text();
        }

        var glassCount = $(_id).val();
        console.log(glassCount);
        if (typeof glassCount == 'undefined') {
          name = name + ' ' + flavor;
          console.log("undefined");
        } else {
          name = name + ' ' + flavor + "(グラス:" + glassCount + "個)";
          console.log("defined");
        }

        if (radiostyle === undefined) {
          alert("飲み方を選んでください。");
          return;
        } else {
          var price = ($("#" + id).data('price'));
          shoppingCart.addItemToCart(name, price, 1, cd1, radiostyle);
          displayCart();
        }
      }

      /**************************************************/

      function callcartoriginal(id, cd1, cd2, random) {
        event.preventDefault();
        var name = $("#" + id).data('name');
        var price = ($("#" + id).data('price'));
        if (typeof random !== 'undefined') {
          var _id = '#counter_' + id + random;
        } else {
          var _id = '#counter_' + id;
        }
        var glassCount = $(_id).val();
        if (typeof glassCount === 'undefined') {
          name = name;
        } else {
          name = name + "(グラス:" + glassCount + "個)";
        }
        shoppingCart.addItemToCart(name, price, 1, cd1, cd2);
        displayCart();
      }

      /**************************************************/
      function clearcheckbox() {
        $('input[name="radiostyle"]').prop('checked', false);
      }
    </script>


    <!-- top menu fixed on scroll -->
    <script>
      var firstElHeight = $('.fixme').height();
      var midmenuEl = $('.midmenu');
      midmenuEl.css('marginTop', firstElHeight + 'px');
    </script>

    <script>
      function increment(id) {
        var value = parseInt(document.getElementById(id).value, 10);
        value = isNaN(value) ? 0 : value;
        value++;
        document.getElementById(id).value = value;
      }

      function decrement(id) {
        var value = parseInt(document.getElementById(id).value, 10);
        value = isNaN(value) ? 0 : value;
        if (value > 1) {
          value--;
        }
        document.getElementById(id).value = value;
      }
      // make first radio button checked by default on page load 
      $(document).ready(function() {
        $('.modal-content').each(function() {
          $(this).find('input[type="radio"]').first().prop('checked', true);
        });
      });
    </script>
  </body>

  </html>
<?php
  if (isset($_GET['menuid'])) {
    echo "<script>openCity(event, '" . $_GET['menuid'] . "')</script>";
  }
} else {
  header("Location: index.php");
}
?>