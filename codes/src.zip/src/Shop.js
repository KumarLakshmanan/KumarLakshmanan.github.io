import React from 'react';
import "./App.css";


class Shop extends React.Component {
    render() {
        return <h1> This is Shop Page </h1>
    }
}
export default Shop;