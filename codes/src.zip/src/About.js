import React from "react";

import "./App.css";

class About extends React.Component {
  render() {
    return <h1> This is About Page </h1>;
  }
}

export default About;
