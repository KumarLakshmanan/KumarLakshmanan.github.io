var script = document.createElement("script");
script.src = chrome.runtime.getURL("/makaan/js/search.js");
document.head.appendChild(script);
