document.getElementsByTagName("html")[0].style.fontSize = "16px";
var myModalContent = `
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"/>
  <button type="button" id="myModalOpen" class="btn btn-primary rounded-0 p-3" data-toggle="modal" data-target="#exampleModal" style="position: fixed;bottom: 0;right: 0;z-index: 9999999;">
      Scrape Data
  </button>
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true" style="background: rgba(0,0,0,0.7);z-index:9999999">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Proptension</h5>
                <button type="button" class="close btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <label for="phone">Phone Number</label>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" id="exampleModalphone" placeholder="Enter Phone Number">
                </div>
                <label for="phone_count">Pull Count</label>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" id="exampleModalpull_count" placeholder="Property Pulling Count">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" id="ScrapData" class="btn btn-primary">Scrap Data</button>
            </div>
        </div>
    </div>
  </div>`;

var myModal = document.createElement("div");
myModal.innerHTML = myModalContent;
myModal.setAttribute("id", "myModal");
var modal = myModal.querySelector(".modal");
var phoneInput = myModal.querySelector("#exampleModalphone");
var pull_count = myModal.querySelector("#exampleModalpull_count");
var scrapSubmit = myModal.querySelector("#ScrapData");

myModal.querySelector(".btn-close").addEventListener("click", function () {
  modal.style.display = "none";
  modal.classList.remove("show");
});
myModal.querySelector("#myModalOpen").addEventListener("click", function () {
  modal.style.display = "block";
  modal.classList.add("show");
});
scrapSubmit.addEventListener("click", async function () {
  scrapSubmit.style.pointerEvents = "none";
  scrapSubmit.style.opacity = "0.5";
  scrapSubmit.innerHTML = "Fetching...";
  var response = await fetch(
    window.location.href.split("#")[0] + "&format=json",
    {
      headers: {
        "X-Requested-With": "XMLHttpRequest",
      },
      method: "GET",
    }
  );
  var data = await response.json();
  var totalProperties = data.totalCount;
  var totalPages = Math.ceil(totalProperties / 20);
  var myData = [];
  try {
    for (var i = 1; i <= totalPages; i++) {
      var response = await fetch(
        window.location.href.split("#")[0] + "&format=json&page=" + i,
        {
          headers: {
            "X-Requested-With": "XMLHttpRequest",
          },
          method: "GET",
        }
      );
      var data = await response.json();
      for (var j = 0; j < data.listingData.data.length; j++) {
        myData.push(await getPropertyDetails(data.listingData.data[j]));
        scrapSubmit.innerHTML = "Fetching " + myData.length + " Properties";
        if (pull_count.value == myData.length) {
          downloadExcel(myData);
          return;
        }
        // getPropertyDetails(data.listingData.data[j]).then(function(data){
        //   myData.push(data);
        //   scrapSubmit.innerHTML = "Fetching " + myData.length + " Properties";
        //   if (pull_count.value == myData.length) {
        //     downloadExcel(myData);
        //     return;
        //   }
        // });
      }
    }
    downloadExcel(myData);
  } catch (error) {
    console.log(error);
    downloadExcel(myData);
  }
  return;
});
function downloadExcel($json) {
  fetch("https://tab2chat.000webhostapp.com/api/jsonToCsv.php", {
    method: "POST",
    body: JSON.stringify($json),
  }).then(function (response) {
    var url = "https://tab2chat.000webhostapp.com/api/makaan.csv";
    var a = document.createElement("a");
    a.href = url;
    a.download =
      new Date().getFullYear() +
      "-" +
      (new Date().getMonth() + 1) +
      "-" +
      new Date().getDate() +
      ".csv";
    a.click();
    scrapSubmit.innerHTML = "Done.";
    scrapSubmit.style.pointerEvents = "all";
    scrapSubmit.style.opacity = "1";
  });
}
async function getPropertyDetails(_data) {
  var propertyDetails = {};
  propertyDetails.propertyName = _data.descriptionTitle || "N/A";
  propertyDetails.id = _data.listingId || "N/A";
  propertyDetails.propertyDescription = _data.description || "N/A";
  propertyDetails.propertyLink = _data.url || "N/A";
  propertyDetails.propertyImage = _data.mainImageURL || "N/A";
  propertyDetails.propertyType = _data.propertyType || "N/A";
  propertyDetails.propertyType = _data.propertyType || "N/A";
  propertyDetails.category = _data.listingCategory || "N/A";
  propertyDetails.bathrooms = _data.bathrooms || "N/A";
  propertyDetails.bedrooms = _data.bedrooms || "N/A";
  propertyDetails.latitude = _data.latitude || "N/A";
  propertyDetails.longitude = _data.longitude || "N/A";
  propertyDetails.furnished = _data.furnished || "N/A";
  propertyDetails.status = _data.propertyStatus || "N/A";
  propertyDetails.price = _data.formattedPrice || "N/A";
  propertyDetails.locality = _data.localityName + ", " + _data.suburbName || "N/A";
  propertyDetails.city = _data.cityName || "N/A";
  propertyDetails.age = _data.propertyAge || "N/A";
  propertyDetails.area = _data.sizeInfo || "N/A";
  propertyDetails.facing = _data.facing || "N/A";
  propertyDetails.postedOn = convertEpochToDate(_data.postedDate) || "N/A";
  propertyDetails.Name = _data.postedBy.name || "N/A";
  propertyDetails.Type = _data.postedBy.type || "N/A";
  propertyDetails.phone = await getBuilderContactNumber(_data.listingId) || "N/A";
  return propertyDetails;
}
function convertEpochToDate(epoch) {
  var date = new Date(epoch);
  return (
    date.getHours() +
    ":" +
    date.getMinutes() +
    " " +
    date.getDate() +
    "/" +
    date.getMonth() +
    "/" +
    date.getFullYear()
  );
}
async function getBuilderContactNumber(listingId) {
  var url = "https://www.makaan.com/apis/nc/enquiries?format=json";
  var headers = {
    "Content-Type": "application/json; charset=utf-8",
    Origin: "https://www.makaan.com",
    "X-Requested-With": "XMLHttpRequest",
  };
  var response1 = await fetch(url, {
    method: "POST",
    headers: headers,
    body: JSON.stringify({
      listingId: listingId,
      phone: phoneInput.value,
      email: "email_" + phoneInput.value + "@email.com",
      name: "name_" + phoneInput.value,
    }),
    credentials: "same-origin",
  });
  var response2Json = await response1.json();
  console.log(response2Json);
  return response2Json.companyPhone;
}

if (window.location.href.indexOf("/listings") > -1) {
  document.body.appendChild(myModal);
}
