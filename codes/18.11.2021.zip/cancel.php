<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

include '../common/inc.common.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_SESSION['staffbango'] = $_POST['staffbango'];
    $_SESSION['roombango'] = $_POST['roombango'];
    header('Location: cancellist.php');
}


$uid = $_GET['uid'];
$_SESSION['uid'] = $uid;
?>



<!DOCTYPE html>
<html lang="ja-jp">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#c9ad86">
    <meta name="msapplication-navbutton-color" content="#c9ad86">
    <meta name="apple-mobile-web-app-status-bar-style" content="#c9ad86">

    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">

    <link rel="icon" href="../images/top-icon.png">
    <link rel="stylesheet" href="../css/main.css">
    <title>セルフオーダー注文削除</title>

    <script src="./script/qrScanner.js"></script>

    <style>
        body {
            font-size: 20px;
        }
    </style>

</head>

<body　>
    <div class="containerPlus">
        <div>
            <p style="color: #595143; font-size:30px; text-align:center;margin-top:0; font-family:'Times New Roman', Times, serif">注文取り消し</p>
        </div>
        <div>
            <script>
                function docReady(fn) {
                    // see if DOM is already available
                    if (document.readyState === "complete" ||
                        document.readyState === "interactive") {
                        // call on next available tick
                        setTimeout(fn, 1);
                    } else {
                        document.addEventListener("DOMContentLoaded", fn);
                    }
                }

                docReady(function() {
                    var resultContainer = document.getElementById('qr-reader-results');
                    var lastResult, countResults = 0;

                    function onScanSuccess(decodedText, decodedResult) {
                        if (decodedText !== lastResult) {
                            ++countResults;
                            lastResult = decodedText;
                            var r = decodedText.split('r=')[1];
                            console.log(r);
                            var rArray = r.split(':');
                            let roomBango = rArray[1].split(',')[0];
                            let staffBango = rArray[2].split(',')[0];
                            fetch('cancel.php', {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
                                    },
                                    body: 'staffbango=' + staffBango + '&roombango=' + roomBango
                                })
                                .then(response => response.text())
                                .then(text => {
                                    console.log(text);
                                    setTimeout(function() {
                                        location.href = 'cancellist.php';
                                    }, 3000);
                                });
                        }
                    }
                    var html5QrcodeScanner = new Html5QrcodeScanner(
                        "qr-reader", {
                            fps: 10,
                            qrbox: 250
                        });
                    html5QrcodeScanner.render(onScanSuccess);


                });
            </script>
            <div id="qr-reader" style="width:500px"></div>
            <div id="qr-reader-results"></div>
        </div>
    </div>
</body>