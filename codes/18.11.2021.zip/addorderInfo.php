<?php
session_start();
header("Content-Type: text/html; charset=UTF-8");

include 'common/inc.common.php';

$sql = "select * from url where active=1";
$urlarr = $Cobj->union($sql);

$sql = "select max(or_order_id) oderid  from confirmedorders";
$colarr = $Cobj->union($sql);


$oderid = $colarr[0]['oderid'];
$oderid = $oderid + 1;
$prd_room = $_POST['selectroom'];
$discper = $_POST['discper'];
$prd_guest = $_POST['selectguest'];
$prd_name = $_POST['prd_name'];
$pro_prcnew = $_POST['pro_prc'];
$qty = $_POST['qty'];
$cdval1 = $_POST['cd1'];
$cdval2 = $_POST['cd2'];
$pro_prc = $_POST['pro_prc'];



$_SESSION['CDVAL2'] = $cdval2;
$_SESSION['QTY'] = $qty;
$_SESSION['isStockDecreased'] = "1";


$prdnew = "";
$cd1new = "";
$cd2new = "";
$qtynew = "";
$prnew = "";
$drinkflgnew = "";
$TheMainData = [];
for ($t = 0; $t < count($pro_prcnew); $t++) {
        $InputArr['productname'] = $prd_name[$t];
        $InputArr['cd1'] = $cdval1[$t];
        $InputArr['cd2'] = $cdval2[$t];


        $proprice = $pro_prc[$t];
        $discval = ($discper / 100) * $proprice;
        $proprice = $proprice - $discval;
        $finalvalprc = floor(($proprice) / 10) * 10;

        $InputArr['productquantity'] = $qty[$t];
        $InputArr['productprice'] = $finalvalprc;
        $InputArr['or_order_id'] = $oderid;
        $InputArr['or_userid'] = $_SESSION['uniqueid'];
        $InputArr['guestname'] = $_POST['selectguest'];
        $InputArr['roomno'] = $_POST['selectroom'];
        $InputArr['tableno'] = $_POST['tableno'];
        $TheMainData[] = $InputArr;

        $prdnew .= "渚/" . $InputArr['productname'] . "@@";
        $cd1new .= $InputArr['cd1'] . "@@";
        $cd2new .= $InputArr['cd2'] . "@@";
        $qtynew .= $InputArr['productquantity'] . "@@";
        $prnew .= $InputArr['productprice'] . "@@";
        $drinkflgnew .= "1@@";
}

$prdnew = rtrim($prdnew, '@@');
$cd1new = rtrim($cd1new, '@@');
$cd2new = rtrim($cd2new, '@@');
$qtynew = rtrim($qtynew, '@@');
$prnew = rtrim($prnew, '@@');
$drinkflgnew = rtrim($drinkflgnew, '@@');


//printer post starts here***********************************

/*1*/
$sendArr['kamokuCD1'] = $cd1new;
/*2*/
$sendArr['kamokuCD2'] = $cd2new;
/*3*/
$sendArr['kamokuName'] = $prdnew;
/*4*/
$sendArr['sisetuName'] = "渚";
/*5*/
$sendArr['userName'] = $_POST['selectguest'];
/*6*/
$sendArr['roomno'] = $_POST['selectroom'];
/*7*/
$sendArr['num'] = $qtynew;
/*8*/
$sendArr['price'] = $prnew;
/*9*/
$sendArr['drinkFlg'] = $drinkflgnew;
/*10*/
$sendArr['tableNo'] = $_POST['tableno'];
/*11*/
$sendArr['placeNo'] = 200000;
/*12*/
$sendArr['userCD'] = 9000;


utf8_decode("kamokuName");
utf8_decode("sisetuName");


//URL to send data to printer (dynamic) - check admin page URL section
$sub_req_url = "http://" . $urlarr[0]['url_name'];

$ch = curl_init($sub_req_url);
$encoded = http_build_query($sendArr); // use this instead of your loop

curl_setopt($ch, CURLOPT_POSTFIELDS,  $encoded);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_POST, 1);
// get the responnse of the curl
$response = curl_exec($ch);
if ($response) {
        echo "success";
        if (strpos($response, 'was incorrect.') || strpos($response, 'was not a number.')) {
                $file = fopen("log.txt", "a");
                $date = date('Y-m-d H:i:s');
                fwrite($file, "\n $date Error : $response" . PHP_EOL . "--------------------------------------------------");
                header('HTTP/1.1 404 Not Found');
                echo "error";
                exit;
        } else {
                for ($i = 0; $i < count($TheMainData); $i++) {
                        try {
                                $Cobj->addNewData("confirmedorders", $TheMainData[$i], "");
                        } catch (Exception $e) {
                                echo "error";
                                exit;
                        }
                }
        }
        fclose($file);
} else {
        $file = fopen("log.txt", "a");
        $date = date('Y-m-d H:i:s');
        fwrite($file, "\n $date Error : この注文は失敗しました　！！ \n kamokuName : $prdnew  \n num : $qtynew \n kamokuCD2 : $cd2new" .
                "\n userName : $_POST[selectguest] | roomno :  $_POST[selectroom] \n サーバーがダウンしているか、" .
                "URLが間違っている可能性があります。" . PHP_EOL . "--------------------------------------------" .
                "-------------------------");
        fclose($file);
        header('HTTP/1.1 404 Not Found');
        echo "error";
        exit;
}

curl_close($ch);
